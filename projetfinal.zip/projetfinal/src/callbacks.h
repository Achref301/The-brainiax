#include <gtk/gtk.h>


void
on_WMbuttonrechercher_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_WMtreeview_row_activated            (GtkTreeView     *WMtreeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_WMbuttonactualiser_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_WMbuttonsupprimer_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_WMbuttonmodifier_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_WMbuttonajouter_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_WMbuttonconfirmermodif_clicked      (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonstat_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_WMbuttonactualiser2_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_WMbuttonrevenir_clicked             (GtkButton       *button,
                                        gpointer         user_data);
