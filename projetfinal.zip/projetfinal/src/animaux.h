#include <gtk/gtk.h>
typedef struct
{
int jour;
int mois;
int annee;
}Datee;


typedef struct
{
char type[30];
char identifiant[30];
char sexe[30];
char poids[30];
Datee date;
}ANIMAL;

void WMajout(ANIMAL a);
void WMrecherche(GtkWidget* WMtreeview);
void WMsuppression(char id[30], ANIMAL a);
void WMaffichage(GtkWidget* WMtreeview);
void WMmodification(char id[30], ANIMAL a);
//int nombre_veau()
//int nombre_brebi()
void nombre(int *b,int *v);
