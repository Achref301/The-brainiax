#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif



#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "animaux.h"

char id[30],idrech[30];
GtkWidget *windowtroupeaux;


void
on_WMbuttonrechercher_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
ANIMAL a;
GtkWidget *windowtroupeaux;
GtkWidget *WMentryid;
GtkWidget *WMtreeview;
FILE*f;
FILE*f2;


windowtroupeaux=lookup_widget(button,"windowtroupeaux");
WMentryid=lookup_widget(button,"WMentryid");
strcpy(idrech,gtk_entry_get_text(GTK_ENTRY(WMentryid)));
f=fopen("animaux.bin","rb");

 if(f!=NULL)
 {
  while(fread(&a,sizeof(ANIMAL),1,f))
     {
       f2=fopen("WMrecherche.bin","ab+");
       if  (f2!=NULL)
   {  
     
     if ((strcmp(a.identifiant,idrech)==0))
     { 
     fwrite(&a,sizeof(ANIMAL),1,f2);
     }
   
     WMtreeview=lookup_widget(windowtroupeaux,"WMtreeview");
     WMrecherche(WMtreeview);
    
        fclose(f2);
    }

 }
 fclose(f);
}
remove("WMrecherche.bin");
}


void
on_WMtreeview_row_activated            (GtkTreeView     *WMtreeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
	gchar* identifiant;
	GtkTreeModel *Model = gtk_tree_view_get_model(WMtreeview);

		if (gtk_tree_model_get_iter(Model, &iter, path)){
				gtk_tree_model_get(GTK_LIST_STORE(Model),&iter,1,&identifiant, -1);
				strcpy(id,identifiant);}
}


void
on_WMbuttonactualiser_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *WMtreeview;
windowtroupeaux=lookup_widget(button,"windowtroupeaux");
WMtreeview=lookup_widget(windowtroupeaux,"WMtreeview");
WMaffichage(WMtreeview);
}


void
on_WMbuttonsupprimer_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
ANIMAL a;
    GtkWidget *WMtreeview;
	    windowtroupeaux=lookup_widget(button,"windowtroupeaux");
	    WMtreeview=lookup_widget(windowtroupeaux,"WMtreeview");
	    WMsuppression(id,a);
            WMaffichage(WMtreeview);
}


void
on_WMbuttonmodifier_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
  gtk_notebook_next_page(GTK_NOTEBOOK(lookup_widget(windowtroupeaux,"WMnotebook")));
                gtk_notebook_next_page(GTK_NOTEBOOK(lookup_widget(windowtroupeaux,"WMnotebook")));
}


void
on_WMbuttonajouter_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
ANIMAL a;char Type[30];
GtkWidget *WMentryajoutid;
GtkWidget *WMentryajoutsexe;
GtkWidget *WMentryajoutpoids;
GtkWidget *WMspinbuttonajoutjour;
GtkWidget *WMspinbuttonajoutmois;
GtkWidget *WMspinbuttonajoutannee;
GtkWidget *WMcomboboxajouttype;
GtkWidget *sortiea;

WMspinbuttonajoutjour=lookup_widget(button, "WMspinbuttonajoutjour");
WMspinbuttonajoutmois=lookup_widget(button, "WMspinbuttonajoutmois");
WMspinbuttonajoutannee=lookup_widget(button, "WMspinbuttonajoutannee");
WMcomboboxajouttype=lookup_widget(button, "WMcomboboxajouttype");
WMentryajoutid=lookup_widget(button,"WMentryajoutid");
WMentryajoutsexe=lookup_widget(button,"WMentryajoutsexe");
WMentryajoutpoids=lookup_widget(button,"WMentryajoutpoids");
sortiea=lookup_widget(button, "WMlabelmsgsucc");

strcpy(a.identifiant,gtk_entry_get_text(GTK_ENTRY(WMentryajoutid)));
strcpy(a.sexe,gtk_entry_get_text(GTK_ENTRY(WMentryajoutsexe)));
strcpy(a.poids,gtk_entry_get_text(GTK_ENTRY(WMentryajoutpoids)));
a.date.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(WMspinbuttonajoutjour));
a.date.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(WMspinbuttonajoutmois));
a.date.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(WMspinbuttonajoutannee));

strcpy(Type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(WMcomboboxajouttype)));
strcpy(a.type,Type);
WMajout(a);
gtk_label_set_text(GTK_LABEL(sortiea),"Ajout effectué avec succès!");
}


void
on_WMbuttonconfirmermodif_clicked      (GtkButton       *button,
                                        gpointer         user_data)
{
ANIMAL a;char Type[30];
GtkWidget *WMcomboboxmodiftype;
GtkWidget *WMentrymodifid;
GtkWidget *WMentrymodifsexe;
GtkWidget *WMspinbuttonmodifjour;
GtkWidget *WMspinbuttonmodifmois;
GtkWidget *WMspinbuttonmodifannee;
GtkWidget *WMentrymodifpoids;
GtkWidget *sortiem;    
	
WMspinbuttonmodifjour=lookup_widget(button, "WMspinbuttonmodifjour");
WMspinbuttonmodifmois=lookup_widget(button, "WMspinbuttonmodifmois");
WMspinbuttonmodifannee=lookup_widget(button, "WMspinbuttonmodifannee");
WMcomboboxmodiftype=lookup_widget(button, "WMcomboboxmodiftype");
WMentrymodifid=lookup_widget(button,"WMentrymodifid");
WMentrymodifsexe=lookup_widget(button,"WMentrymodifsexe");
WMentrymodifpoids=lookup_widget(button,"WMentrymodifpoids");
sortiem=lookup_widget(button, "WMlabelmodifreus");

strcpy(a.identifiant,gtk_entry_get_text(GTK_ENTRY(WMentrymodifid)));
strcpy(a.sexe,gtk_entry_get_text(GTK_ENTRY(WMentrymodifsexe)));
strcpy(a.poids,gtk_entry_get_text(GTK_ENTRY(WMentrymodifpoids)));
a.date.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(WMspinbuttonmodifjour));
a.date.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(WMspinbuttonmodifmois));
a.date.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(WMspinbuttonmodifannee));
strcpy(Type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(WMcomboboxmodiftype)));
strcpy(a.type,Type);
WMmodification(id,a);
gtk_label_set_text(GTK_LABEL(sortiem),"Modification effectuée avec succès!");
}




void

on_buttonstat_clicked                     (GtkButton       *button,
                                        gpointer         user_data)

{

int *b,*v,a=0,c=0;
char chv[30],chb[30];
b=&a;
v=&c;
GtkWidget *windowtroupeaux;
GtkWidget *windowstatistique;
GtkWidget *labelBrebi;
GtkWidget *labelVeau;
ANIMAL e;
windowtroupeaux = lookup_widget(button,"windowtroupeaux");
gtk_widget_destroy(windowtroupeaux);
windowstatistique = create_windowstatistique();
gtk_widget_show(windowstatistique);


labelBrebi=lookup_widget(windowstatistique,"labelBrebi");
labelVeau=lookup_widget(windowstatistique,"labelVeau");
 nombre( b ,v);
sprintf(chb,"%d",a);
sprintf(chv,"%d",c);
gtk_label_set_text(labelBrebi,chb);
gtk_label_set_text(labelVeau,chv);

}







void
on_WMbuttonactualiser2_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
/*GtkWidget *labelVeau;
GtkWidget *labelBrebi;

labelVeau=lookup_widget(button,"labelVeau");
labelBrebi=lookup_widget(button,"labelBrebi");
int veau,brebi;
char veauCh[30], brebiCh[30];
brebi = nombre_brebi();
veau = nombre_veau();
sprintf(veauCh, "%d", veau);
sprintf(brebiCh, "%d", brebi);
gtk_label_set_text(GTK_LABEL(labelVeau), veauCh);
gtk_label_set_text(GTK_LABEL(labelBrebi), brebiCh);*/

}


void
on_WMbuttonrevenir_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowtroupeaux;
GtkWidget *windowstatistique;

windowstatistique = lookup_widget(button,"windowstatistique");
gtk_widget_destroy(windowstatistique);
windowtroupeaux= create_windowtroupeaux();
gtk_widget_show(windowtroupeaux);

}

