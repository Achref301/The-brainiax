#include <stdlib.h>
#include <stdio.h>
#include<string.h>

#include "animaux.h"


enum{TYPE,IDENTIFIANT,SEXE,DATE,POIDS,COLUMNS};
//------------------------------------------------------********---------------------------------------------------
void WMaffichage(GtkWidget* WMtreeview)
{
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;
ANIMAL a;char Date[100];
store=NULL;
FILE *f;
store=gtk_tree_view_get_model(WMtreeview);
if (store==NULL)
{
renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Type", renderer, "text",TYPE, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (WMtreeview), column);


renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Identifiant", renderer, "text",IDENTIFIANT, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (WMtreeview), column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Sexe", renderer, "text",SEXE, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (WMtreeview), column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Date", renderer, "text",DATE, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (WMtreeview), column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Poids", renderer, "text",POIDS, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (WMtreeview), column);}

store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
f=fopen("animaux.bin","rb");
if(f==NULL)
{return;}
else
{f=fopen("animaux.bin","ab+");
while(fread(&a,sizeof(ANIMAL),1,f))
{sprintf(Date,"%d/%d/%d",a.date.jour,a.date.mois,a.date.annee);
gtk_list_store_append(store,&iter);
gtk_list_store_set(store,&iter,TYPE,a.type,IDENTIFIANT,a.identifiant,SEXE,a.sexe,DATE,Date,POIDS,a.poids,-1);
}
fclose(f);
gtk_tree_view_set_model(GTK_TREE_VIEW(WMtreeview),GTK_TREE_MODEL (store));
g_object_unref(store);}}


//-------------------------------------------------------*******-----------------------------------------------------------

void WMajout (ANIMAL a){
FILE*f=NULL; 
f=fopen("animaux.bin","ab+");
fwrite(&a,sizeof(ANIMAL),1,f);  
fclose(f);
 
}
//------------------------------------------------------------------------------------------------------------------------

void WMsuppression(char id[30],ANIMAL a){
FILE*f;
FILE*g;
f=fopen("animaux.bin","rb+");
g=fopen("WMtmp.bin","wb+");
if(g!=NULL){
while(fread(&a,sizeof(ANIMAL),1,f))
{
if (strcmp(a.identifiant,id)!=0){
fwrite(&a,sizeof(ANIMAL),1,g);

}
}
}fclose(f);
fclose(g);
remove("animaux.bin");
rename("WMtmp.bin","animaux.bin");
}

//------------------------------------------------------------------------------------------------------------------------

void WMmodification(char id[30],ANIMAL a)
{

	WMsuppression(id,a);
	WMajout(a);

}
//------------------------------------------------------------------------------------------------------------------------
void WMrecherche(GtkWidget* WMtreeview)
{
GtkCellRenderer *renderer;
 GtkTreeViewColumn *column;
 GtkTreeIter iter;
 GtkListStore *store;

store=NULL;ANIMAL a;
 FILE *f2;char Date[100]; 
 store=gtk_tree_view_get_model(WMtreeview);
 if (store==NULL)
{

   renderer=gtk_cell_renderer_text_new();
   column= gtk_tree_view_column_new_with_attributes("Type",renderer, "text",TYPE,NULL);
   gtk_tree_view_append_column(GTK_TREE_VIEW(WMtreeview), column);
 
   renderer=gtk_cell_renderer_text_new();
   column= gtk_tree_view_column_new_with_attributes("Identifiant",renderer, "text",IDENTIFIANT,NULL);
   gtk_tree_view_append_column(GTK_TREE_VIEW(WMtreeview), column);
  
   renderer=gtk_cell_renderer_text_new();
   column= gtk_tree_view_column_new_with_attributes("Sexe",renderer, "text",SEXE,NULL);
   gtk_tree_view_append_column(GTK_TREE_VIEW(WMtreeview), column);
   
   renderer=gtk_cell_renderer_text_new();
   column= gtk_tree_view_column_new_with_attributes("Date",renderer, "text",DATE,NULL);
   gtk_tree_view_append_column(GTK_TREE_VIEW(WMtreeview), column);
   
   renderer=gtk_cell_renderer_text_new();
   column= gtk_tree_view_column_new_with_attributes("Poids",renderer, "text",POIDS,NULL);
   gtk_tree_view_append_column(GTK_TREE_VIEW(WMtreeview), column);}
  
store=gtk_list_store_new(COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);
f2=fopen("WMrecherche.bin", "rb");
if(f2==NULL)
{
 return;
}
else 
{ f2=fopen("WMrecherche.bin", "ab+");
    while(fread(&a,sizeof(ANIMAL),1,f2))
     {sprintf(Date,"%d/%d/%d",a.date.jour,a.date.mois,a.date.annee);
gtk_list_store_append (store,&iter);
gtk_list_store_set (store,&iter,TYPE,a.type,IDENTIFIANT,a.identifiant,SEXE,a.sexe,DATE,Date,POIDS,a.poids, -1);
}
fclose(f2);
gtk_tree_view_set_model (GTK_TREE_VIEW (WMtreeview), GTK_TREE_MODEL (store));
g_object_unref (store);
}
}
//------------------------------------------------------------------------------------------------------------------------
/*int nombre_veau()
{
FILE *fp;
int veau=0;
ANIMAL a;
fp = fopen("animaux.bin", "rb");
if (fp==NULL)
{
	return;
}
else{
	while (fread(&a,sizeof(a),1,fp))
	{
		if (strcmp(a.type,"Veau")==0)
		{
			veau++;
		}
	}
}
fclose(fp);
return (veau);
}*/


/*int nombre_brebi()
{
FILE *fp;
int brebi=0;
ANIMAL a;
fp = fopen("animaux.bin", "rb");
if (fp==NULL)
{
	return;
}
else{
	while (fread(&a,sizeof(a),1,fp))
	{
		if (strcmp(a.type,"Brebi")==0)
		{
			brebi++;
		}
	}
}
fclose(fp);
return(brebi);
}*/


void nombre(int *b,int *v)
{
FILE *f;
ANIMAL a;
f = fopen("animaux.bin", "rb");
while (fread(&a,sizeof(a),1,f))
if(strcmp(a.type,"Brebi")==0)
*b+=1;
else
if(strcmp(a.type,"Veau")==0)
*v+=1;

fclose(f);


} 













