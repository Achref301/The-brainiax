#include <gtk/gtk.h>


void
on_ASbuttonmenup_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_AStreeview_row_activated            (GtkTreeView     *AStreeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_ASbuttonrechercher_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_ASbuttonactualiser_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_ASbuttonsupprimer_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_ASbuttongomodifier_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_ASbuttonboard_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_ASbuttonajouter_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_ASbuttonmodifier_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_ASbuttonseche_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_FMtreeview_row_activated            (GtkTreeView     *FMtreeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);



void
on_FMbuttonactualiser_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_FMbuttonsupprimer_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_FMbuttongoajouter_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_FMbuttongomodifier_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_FMbuttonpresence_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_FMbuttonajouter_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_FMbuttonmodifier_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_FMtreeview2_row_activated           (GtkTreeView     *FMtreeview1,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_FMbuttonokpres_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_FMbuttonpresafficher_clicked        (GtkButton       *button,
                                        gpointer         user_data);

void
on_FMbuttonpressupp_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_FMbuttontaux_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_FMbuttonokdialogue_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_KKtreeview_row_activated            (GtkTreeView     *KKtreeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_KKbuttonrechercher_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_KKbuttonactualiser_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_KKbuttonboard_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_KKbuttongomodifier_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_KKbuttongoajouter_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_KKbuttonsupprimer_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_KKbuttonajouter_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_KKbuttonconfirmermodif_clicked      (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonmenucl_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonmenut_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_WMtreeview_row_activated            (GtkTreeView     *WMtreeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_WMbuttonrechercher_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_WMbuttonactualiser_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_WMbuttonsupprimer_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_WMbuttongoajouter_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_WMbuttongomodifier_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_WMbuttonstatistique_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_WMbuttonajouter_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_WMbuttonmodifier_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_WMbuttonretour_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonmenue_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_Etreeview_row_activated             (GtkTreeView     *Etreeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_Ebuttonrechercher_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_Ebuttonactualiser_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_Ebuttonsupprimer_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_Ebuttongoajouter_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_Ebuttongomodifier_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_Ebuttonajouter_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_Ebuttonmodifier_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonmenucp_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_AZtreeview_row_activated            (GtkTreeView     *AZtreeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_AZbuttonsupprimer_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_AZbuttonactualiser_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_AZbuttonrechercher_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_AZbuttonboard_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_AZbuttongoajouter_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_AZbuttongomodifier_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_AZbuttonajouter_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_AZbuttonmodifier_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_AZbuttonaffichboard_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_FMbuttonrechercher_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_KKbuttonmodifier_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_ASbuttongoajouter_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttoninscription_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonretourlogin_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttongoinscription_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonlogin_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonretourlogin_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttoninscription_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttongoinscription_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonlogin_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttono_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttongologin_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttongop_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttongoo_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttongocp_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttongoe_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttongot_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttongoauth_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttongocl_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttongoauthentification_clicked    (GtkButton       *button,
                                        gpointer         user_data);
