#include <gtk/gtk.h>
//-----------------------------------------------------------PLANTATIONS----------------------------------------------------
typedef struct
{
int jour;
int mois;
int annee;
}Datee;


typedef struct
{
char type[30];
char identifiant[30];
int nombre;
int recolte;
Datee date;
}PLANTE;

void ASajout(PLANTE p);
void ASrecherche(GtkWidget* AStreeview);
void ASsuppression(char id[30], PLANTE p);
void ASaffichage(GtkWidget* AStreeview);
void ASmodification(char id[30], PLANTE p);
int anneeseche(PLANTE p);
int recoltemin(PLANTE p);
int verif(char x[]);
int verifid(char id[30]);
//----------------------------------------------------------OUVRIERS---------------------------------------------------
typedef struct 
{
char etat[30] ;
char identifiant[30];
Datee date;
}ouvabs;
typedef struct
{
char sexe[30];
char identifiant[30];
char cin[30];
char numtel[30];
Datee date;
}ouvrier;



void FMajout(ouvrier o);
void FMrecherche(GtkWidget* treeviewfm, char id[]);
void FMsuppression(char id[]);
void FMaffichage(GtkWidget *treeviewfm);
void FMmodification(char id[], ouvrier o);
void FMajoutpresence(ouvabs x);
void FMaffichageabs(GtkWidget* treeviewpresence2fm);
void FMsuppressionpresence(char id[30], ouvabs x);
int tauxab() ;
int nouvr() ;
//-------------------------------------------------------CAPTEURS-------------------------------------------------------
typedef struct
{
char type[30];
char identifiant[30];
char marque[30];
char valeur[30];
Datee date;
}CAPTEURS;

void AZajout(CAPTEURS c);
void AZrecherche(GtkWidget* AZtreeview);
void AZsuppression(char id[30], CAPTEURS c);
void AZaffichage(GtkWidget* AZtreeview);
void AZmodification(char id[30],CAPTEURS c);
void affichagestat(GtkWidget* stattreeview);
int nombret(CAPTEURS c);
int nombreh(CAPTEURS c);
int Mrq_Deff(CAPTEURS c);
//-----------------------------------------------------TROUPEAUX---------------------------------------------------------
typedef struct
{
char type[30];
char identifiant[30];
char sexe[30];
char poids[30];
Datee date;
}ANIMAL;

void WMajout(ANIMAL a);
void WMrecherche(GtkWidget* WMtreeview);
void WMsuppression(char id[30], ANIMAL a);
void WMaffichage(GtkWidget* WMtreeview);
void WMmodification(char id[30], ANIMAL a);
void nombre(int *b,int *v);
//---------------------------------------------------EQUIPEMENTS--------------------------------------------------------
typedef struct
{
char type[30];
char identifiant[30];
char nombre[30];
char com[100];
Datee date;
}EQUIP;

void Eajout(EQUIP e);
void Erecherche(GtkWidget* Etreeview);
void Esuppression(char id[30], EQUIP e);
void Eaffichage(GtkWidget* Etreeview);
void Emodification(char id[30], EQUIP e);
//----------------------------------------------------CLIENTS-------------------------------------------------------------
typedef struct
{
char np[30];
char identifiant[30];
char sexe[30];
char valeur[30];
Datee date;
}CLIENT;

void KKajout(CLIENT c);
void KKrecherche(GtkWidget* KKtreeview);
void KKsuppression(char id[30], CLIENT c);
void KKaffichage(GtkWidget* KKtreeview);
void KKmodification(char id[30], CLIENT c);
//----------------------------------------------------LOGIN----------------------------------------------------------------
typedef struct
{
char nom[30];
char prenom[30];
char uname[30];
char password[30];
char role[30];
}insc;
typedef struct 
{
char auname[30] ;
char apass[30];
}auth;
void inscription(insc i);
int login(auth a);
int verifl (insc in ) ; 
int veriflogin(auth a) ;
