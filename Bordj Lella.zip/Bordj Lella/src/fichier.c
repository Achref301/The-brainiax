#include <stdlib.h>
#include <stdio.h>
#include<string.h>

#include "fichier.h"

//--------------------------------------------------------PLANTATIONS---------------------------------------------------------------
enum{TYPE,IDENTIFIANT,NOMBRE,DATE,RECOLTE,COLUMNS};

void ASaffichage(GtkWidget* AStreeview)
{
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;
PLANTE p;char Date[100];char Nbr[100];char Recolte[100]; 
store=NULL;
FILE *f;
store=gtk_tree_view_get_model(AStreeview);
if (store==NULL)
{
renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Type", renderer, "text",TYPE, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (AStreeview), column);


renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Identifiant", renderer, "text",IDENTIFIANT, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (AStreeview), column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Nombre", renderer, "text",NOMBRE, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (AStreeview), column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Date", renderer, "text",DATE, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (AStreeview), column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Recolte", renderer, "text",RECOLTE, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (AStreeview), column);}

store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
f=fopen("plantations.bin","rb");
if(f==NULL)
{return;}
else
{f=fopen("plantations.bin","ab+");
while(fread(&p,sizeof(PLANTE),1,f))
{sprintf(Date,"%d/%d/%d",p.date.jour,p.date.mois,p.date.annee);
sprintf(Nbr,"%d",p.nombre);
sprintf(Recolte,"%d",p.recolte);
gtk_list_store_append(store,&iter);
gtk_list_store_set(store,&iter,TYPE,p.type,IDENTIFIANT,p.identifiant,NOMBRE,Nbr,DATE,Date,RECOLTE,Recolte,-1);
}
fclose(f);
gtk_tree_view_set_model(GTK_TREE_VIEW(AStreeview),GTK_TREE_MODEL (store));
g_object_unref(store);}}




void ASajout (PLANTE p){
FILE*f=NULL; 
f=fopen("plantations.bin","ab+");
fwrite(&p,sizeof(PLANTE),1,f);  
fclose(f);
 
}


void ASsuppression(char id[30],PLANTE p){
FILE*f;
FILE*g;
f=fopen("plantations.bin","rb+");
g=fopen("AStmp.bin","wb+");
if(g!=NULL){
while(fread(&p,sizeof(PLANTE),1,f))
{
if (strcmp(p.identifiant,id)!=0){
fwrite(&p,sizeof(PLANTE),1,g);

}
}
}fclose(f);
fclose(g);
remove("plantations.bin");
rename("AStmp.bin","plantations.bin");
}



void ASmodification(char id[30],PLANTE p)
{

	ASsuppression(id,p);
	ASajout(p);

}

void ASrecherche(GtkWidget* AStreeview)
{
GtkCellRenderer *renderer;
 GtkTreeViewColumn *column;
 GtkTreeIter iter;
 GtkListStore *store;

store=NULL;PLANTE p;
 FILE *f2;char Date[100];char Nbr[100];char Recolte[100]; 
 store=gtk_tree_view_get_model(AStreeview);
 if (store==NULL)
{

   renderer=gtk_cell_renderer_text_new();
   column= gtk_tree_view_column_new_with_attributes("Type",renderer, "text",TYPE,NULL);
   gtk_tree_view_append_column(GTK_TREE_VIEW(AStreeview), column);
 
   renderer=gtk_cell_renderer_text_new();
   column= gtk_tree_view_column_new_with_attributes("Identifiant",renderer, "text",IDENTIFIANT,NULL);
   gtk_tree_view_append_column(GTK_TREE_VIEW(AStreeview), column);
  
   renderer=gtk_cell_renderer_text_new();
   column= gtk_tree_view_column_new_with_attributes("Nombre",renderer, "text",NOMBRE,NULL);
   gtk_tree_view_append_column(GTK_TREE_VIEW(AStreeview), column);
   
   renderer=gtk_cell_renderer_text_new();
   column= gtk_tree_view_column_new_with_attributes("Date",renderer, "text",DATE,NULL);
   gtk_tree_view_append_column(GTK_TREE_VIEW(AStreeview), column);
   
   renderer=gtk_cell_renderer_text_new();
   column= gtk_tree_view_column_new_with_attributes("Recolte",renderer, "text",RECOLTE,NULL);
   gtk_tree_view_append_column(GTK_TREE_VIEW(AStreeview), column);}
  
store=gtk_list_store_new(COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);
f2=fopen("ASrecherche.bin", "rb");
if(f2==NULL)
{
 return;
}
else 
{ f2=fopen("ASrecherche.bin", "ab+");
    while(fread(&p,sizeof(PLANTE),1,f2))
{sprintf(Date,"%d/%d/%d",p.date.jour,p.date.mois,p.date.annee);
sprintf(Nbr,"%d",p.nombre);
sprintf(Recolte,"%d",p.recolte);
gtk_list_store_append (store,&iter);
gtk_list_store_set (store,&iter,TYPE,p.type,IDENTIFIANT,p.identifiant,NOMBRE,Nbr,DATE,Date,RECOLTE,Recolte, -1);
}
fclose(f2);
gtk_tree_view_set_model (GTK_TREE_VIEW (AStreeview), GTK_TREE_MODEL (store));
g_object_unref (store);
}}

int anneeseche (PLANTE p)
{FILE*f;
int i,min,ann,aux,aux1,aux2,permut,k,j=0,n=0;

//détermination du nombre des lignes dans mon fichier binaire

f=fopen("plantations.bin","rb");
while(fread(&p,sizeof(PLANTE),1,f)!=0){
	n++;}

fclose(f);

//initialisation de mon tableau et son remplissage

int t[2][n];
f=fopen("plantations.bin","ab+");
while(fread(&p,sizeof(PLANTE),1,f)!=0){
		
if(j<n){
			t[0][j]=p.date.annee;
			t[1][j]=p.recolte;
j++;
			}}	
fclose(f); 

//Tri des années
do
{
permut=0; 
for( i=0 ;i<n-1;i++ )
{
if (t[0][i]>t[0][i+1])
{

aux1=t[0][i];
aux2=t[1][i];

t[0][i]=t[0][i+1];
t[1][i]=t[1][i+1];

t[0][i+1]=aux1;
t[1][i+1]=aux2;

permut=1;
}
}
}
while (permut == 1);

//suppression des années dupliquées et somme des récoltes de chaque année

   for (i=0;i<n;i++) {
      for (j=i+1;j<n;) {
         if (t[0][j]==t[0][i]) {t[1][i]=t[1][i]+t[1][i+1];
            for (k=j;k<n;k++) {
               t[0][k]=t[0][k+1];
	       t[1][k]=t[1][k+1];
            }
            n--;
         } else
            j++;
      }
   }
//Determination de l'année la plus sèche
        ann=t[0][0];
	min=t[1][0];
    for(i=1;i<n;i++)
    {
       if(t[1][0] > t[1][i])
          { min=t[1][i];
	   ann=t[0][i];}
    }
	return ann;

	}		

int recoltemin(PLANTE p)
{FILE*f;
int i,min,ann,aux,aux1,aux2,permut,k,j=0,n=0;

//détermination du nombre des lignes dans mon fichier binaire

f=fopen("plantations.bin","rb");
while(fread(&p,sizeof(PLANTE),1,f)!=0){
	n++;}

fclose(f);

//initialisation de mon tableau et son remplissage

int t[2][n];
f=fopen("plantations.bin","ab+");
while(fread(&p,sizeof(PLANTE),1,f)!=0){
		
if(j<n){
			t[0][j]=p.date.annee;
			t[1][j]=p.recolte;
j++;
			}}	
fclose(f); 

//Tri des années
do
{
permut=0; 
for( i=0 ;i<n-1;i++ )
{
if (t[0][i]>t[0][i+1])
{

aux1=t[0][i];
aux2=t[1][i];

t[0][i]=t[0][i+1];
t[1][i]=t[1][i+1];

t[0][i+1]=aux1;
t[1][i+1]=aux2;

permut=1;
}
}
}
while (permut == 1);

//suppression des années dupliquées et somme des récoltes de chaque année

   for (i=0;i<n;i++) {
      for (j=i+1;j<n;) {
         if (t[0][j]==t[0][i]) {t[1][i]=t[1][i]+t[1][i+1];
            for (k=j;k<n;k++) {
               t[0][k]=t[0][k+1];
	       t[1][k]=t[1][k+1];
            }
            n--;
         } else
            j++;
      }
   }
//Determination de l'année la plus sèche
        ann=t[0][0];
	min=t[1][0];
    for(i=1;i<n;i++)
    {
       if(t[1][0] > t[1][i])
          { min=t[1][i];
	   ann=t[0][i];}
    }
	return min;

	}

int verif(char x[])
{
   int i=0;
   if (strcmp(x, "")==0)
   {
      i=0;
   }
   else
   {
      i=1;
   }
   return i;
}

int verifid(char id[30])
{
   PLANTE p;
   int res = 1;
   FILE *f;
   f = fopen("plantations.bin", "ab+");
   if (f != NULL)
   {
      while (fread(&p,sizeof(PLANTE),1,f))
      {
         if (strcmp(id,p.identifiant) == 0)
         {
            res = 0;
         }
         else
         {
            res = 1;
         }
      }
   }
   fclose(f);
   return res;
}
//------------------------------------------------------OUVRIERS----------------------------------------------------------------
enum {ID,DATEP,ETAT,COLUMNSP};
enum{SEXE1,IDENTIFIANT1,CIN1,DATE1,NUMTEL,COLUMNS1};

void FMaffichage(GtkWidget* FMtreeview)
{
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;
ouvrier o;
char Date[100];
store=NULL;
FILE *f;
store=gtk_tree_view_get_model(FMtreeview);
if (store==NULL)
{
renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("sexe", renderer, "text",SEXE1, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (FMtreeview), column);


renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Identifiant", renderer, "text",IDENTIFIANT1, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (FMtreeview), column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("CIN", renderer, "text",CIN1, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (FMtreeview), column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Date", renderer, "text",DATE1, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (FMtreeview), column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("numero de telephone", renderer, "text",NUMTEL, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (FMtreeview), column);}



store=gtk_list_store_new(COLUMNS1,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
f=fopen("ouvrier.bin","rb");
if(f==NULL)
{return;}
else
{f=fopen("ouvrier.bin","ab+");
while(fread(&o,sizeof(ouvrier),1,f))
{sprintf(Date,"%d/%d/%d",o.date.jour,o.date.mois,o.date.annee);
gtk_list_store_append(store,&iter);
gtk_list_store_set(store,&iter,SEXE1,o.sexe,IDENTIFIANT1,o.identifiant,CIN1,o.cin,DATE1,Date,NUMTEL,o.numtel,-1);
}
fclose(f);
gtk_tree_view_set_model(GTK_TREE_VIEW(FMtreeview),GTK_TREE_MODEL (store));
g_object_unref(store);}}


void FMajout (ouvrier o){
FILE*f=NULL; 
f=fopen("ouvrier.bin","ab+");
fwrite(&o,sizeof(ouvrier),1,f);  
fclose(f);
 
}

void FMsuppression(char id[]){
FILE*f;
FILE*g;
ouvrier o;
f=fopen("ouvrier.bin","rb+");
g=fopen("FMtmp.bin","wb+");
if(g!=NULL){
while(fread(&o,sizeof(ouvrier),1,f))
{
if (strcmp(o.identifiant,id)!=0){
fwrite(&o,sizeof(ouvrier),1,g);

}
}
}fclose(f);
fclose(g);
remove("ouvrier.bin");
rename("FMtmp.bin","ouvrier.bin");
}


void FMsuppressionpresence(char id[30],ouvabs x){
FILE*f;
FILE*g;
f=fopen("ouvabs.bin","rb+");
g=fopen("FMtmp1.bin","wb+");
if(g!=NULL){
while(fread(&x,sizeof(ouvabs),1,f))
{
if (strcmp(x.identifiant,id)!=0){
fwrite(&x,sizeof(ouvabs),1,g);

}
}
}fclose(f);
fclose(g);
remove("ouvabs.bin");
rename("FMtmp1.bin","ouvabs.bin");
}

void FMmodification(char id[],ouvrier ouv)
{

ouvrier o ;  
 

FILE *f;


f=fopen("ouvrier.bin","rb+");
if (f!=NULL)
{
while(fread(&o,sizeof(ouvrier),1,f))
{
    if(strcmp(id,o.identifiant)==0)
            {
          strcpy(ouv.identifiant,id) ; 
      if  (strcmp(ouv.cin,"")==0) {strcpy(ouv.cin,o.cin);}
        if  (strcmp(ouv.sexe,"")==0) {strcpy(ouv.sexe,o.sexe);}
        if  (strcmp(ouv.numtel,"")==0) {strcpy(ouv.numtel,o.numtel);}

      
	    }
}
}

fclose(f);

	FMsuppression(id);
	FMajout(ouv);

}

void FMrecherche(GtkWidget* FMtreeview,char id[])
{
GtkCellRenderer *renderer;
 GtkTreeViewColumn *column;
 GtkTreeIter iter;
 GtkListStore *store;

store=NULL; ouvrier o;
 FILE *f2;char Date[100]; 
 store=gtk_tree_view_get_model(FMtreeview);
 if (store==NULL)
{

  renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("sexe", renderer, "text",SEXE1, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (FMtreeview), column);


renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Identifiant", renderer, "text",IDENTIFIANT1, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (FMtreeview), column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("CIN", renderer, "text",CIN1, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (FMtreeview), column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Date", renderer, "text",DATE1, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (FMtreeview), column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("numero de telephone", renderer, "text",NUMTEL, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (FMtreeview), column);}



store=gtk_list_store_new(COLUMNS1,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
f2=fopen("FMrecherche.bin", "rb");
if(f2==NULL)
{
 return;
}
else 
{ f2=fopen("FMrecherche.bin", "ab+");
    while(fread(&o,sizeof(ouvrier),1,f2))
     {sprintf(Date,"%d/%d/%d",o.date.jour,o.date.mois,o.date.annee);

if (strcmp(id,o.identifiant)==0) 
{
gtk_list_store_append (store,&iter);
gtk_list_store_set; gtk_list_store_set(store,&iter,SEXE1,o.sexe,IDENTIFIANT1,o.identifiant,CIN1,o.cin,DATE1,Date,NUMTEL,o.numtel,-1);
}
}
fclose(f2);
gtk_tree_view_set_model (GTK_TREE_VIEW (FMtreeview), GTK_TREE_MODEL (store));
g_object_unref (store);
}
}

void FMajoutpresence(ouvabs x)
{
FILE*f=NULL; 
f=fopen("ouvabs.bin","ab+");
fwrite(&x,sizeof(ouvabs),1,f);  
fclose(f);
 
}

void FMaffichageabs(GtkWidget* FMtreeview2)
{
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;

ouvabs x;

char Date[100];

store=NULL;
FILE *f;

store=gtk_tree_view_get_model(FMtreeview2);

if (store==NULL)
{
renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Identifiant", renderer, "text",ID, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (FMtreeview2), column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Date", renderer, "text",DATEP, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (FMtreeview2), column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Etat", renderer, "text",ETAT, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (FMtreeview2), column);

store=gtk_list_store_new(COLUMNSP,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
f=fopen("ouvabs.bin","rb");
if(f==NULL)
{
return;
} 
else
{
f=fopen("ouvabs.bin","ab+");
while(fread(&x,sizeof(ouvabs),1,f))
{

sprintf(Date,"%d/%d/%d",x.date.jour,x.date.mois,x.date.annee);
gtk_list_store_append(store,&iter);
gtk_list_store_set(store,&iter,ETAT,x.etat,ID,x.identifiant,DATEP,Date,-1);

}
fclose(f);
}
gtk_tree_view_set_model(GTK_TREE_VIEW(FMtreeview2),GTK_TREE_MODEL (store));
g_object_unref(store);
}
}


int tauxab() 
{
FILE*f;
int t=0; 
ouvabs x;
f=fopen("ouvabs.bin","rb+");

if(f!=NULL)
{
while(fread(&x,sizeof(ouvabs),1,f))
{
if (strcmp(x.etat,"Absent")==0)
{
t++;
}
}

fclose(f);
}

return t ; 
}


int nouvr() 
{
FILE*f;
int nouv=0; 
ouvrier o;
f=fopen("ouvrier.bin","rb+");

if(f!=NULL)
{
while(fread(&o,sizeof(ouvrier),1,f))
{

nouv++;

}

fclose(f);
}

return nouv ; 
}
//--------------------------------------------------------CAPTEURS------------------------------------------------------------
enum{TYPE2,IDENTIFIANT2,MARQUE,DATE2,VALEUR2,COLUMNS2};
enum{TYPEC,IDENTIFIANTC,MARQUEC,VALEURC,COLUMNSC};

void AZaffichage(GtkWidget* AZtreeview)
{
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;
CAPTEURS c;char Date[100];
store=NULL;
FILE *f;
store=gtk_tree_view_get_model(AZtreeview);
if (store==NULL)
{
renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Type", renderer, "text",TYPE2, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (AZtreeview), column);


renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Identifiant", renderer, "text",IDENTIFIANT2, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (AZtreeview), column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Marque", renderer, "text",MARQUE, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (AZtreeview), column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Date", renderer, "text",DATE2, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (AZtreeview), column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Valeur", renderer, "text",VALEUR2, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (AZtreeview), column);}

store=gtk_list_store_new(COLUMNS2,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
f=fopen("capteurs.bin","rb");
if(f==NULL)
{return;}
else
{f=fopen("capteurs.bin","ab+");
while(fread(&c,sizeof(CAPTEURS),1,f))
{sprintf(Date,"%d/%d/%d",c.date.jour,c.date.mois,c.date.annee);
gtk_list_store_append(store,&iter);
gtk_list_store_set(store,&iter,TYPE2,c.type,IDENTIFIANT2,c.identifiant,MARQUE,c.marque,DATE2,Date,VALEUR2,c.valeur,-1);
}
fclose(f);
gtk_tree_view_set_model(GTK_TREE_VIEW(AZtreeview),GTK_TREE_MODEL (store));
g_object_unref(store);}}



void AZajout (CAPTEURS c){
FILE*f=NULL; 
f=fopen("capteurs.bin","ab+");
fwrite(&c,sizeof(CAPTEURS),1,f);  
fclose(f);
 
}


void AZsuppression(char id[30],CAPTEURS c){
FILE*f;
FILE*g;
f=fopen("capteurs.bin","rb+");
g=fopen("AZtmp.bin","wb+");
if(g!=NULL){
while(fread(&c,sizeof(CAPTEURS),1,f))
{
if (strcmp(c.identifiant,id)!=0){
fwrite(&c,sizeof(CAPTEURS),1,g);

}
}
}fclose(f);
fclose(g);
remove("capteurs.bin");
rename("AZtmp.bin","capteurs.bin");
}



void AZmodification(char id[30],CAPTEURS c)
{

	AZsuppression(id,c);
	AZajout(c);

}

void AZrecherche(GtkWidget* AZtreeview)
{
GtkCellRenderer *renderer;
 GtkTreeViewColumn *column;
 GtkTreeIter iter;
 GtkListStore *store;

store=NULL;CAPTEURS c;
 FILE *f2;char Date[100]; 
 store=gtk_tree_view_get_model(AZtreeview);
 if (store==NULL)
{

   renderer=gtk_cell_renderer_text_new();
   column= gtk_tree_view_column_new_with_attributes("Type",renderer, "text",TYPE2,NULL);
   gtk_tree_view_append_column(GTK_TREE_VIEW(AZtreeview), column);
 
   renderer=gtk_cell_renderer_text_new();
   column= gtk_tree_view_column_new_with_attributes("Identifiant",renderer, "text",IDENTIFIANT2,NULL);
   gtk_tree_view_append_column(GTK_TREE_VIEW(AZtreeview), column);
  
   renderer=gtk_cell_renderer_text_new();
   column= gtk_tree_view_column_new_with_attributes("Marque",renderer, "text",MARQUE,NULL);
   gtk_tree_view_append_column(GTK_TREE_VIEW(AZtreeview), column);
   
   renderer=gtk_cell_renderer_text_new();
   column= gtk_tree_view_column_new_with_attributes("Date",renderer, "text",DATE2,NULL);
   gtk_tree_view_append_column(GTK_TREE_VIEW(AZtreeview), column);
   
   renderer=gtk_cell_renderer_text_new();
   column= gtk_tree_view_column_new_with_attributes("Valeur",renderer, "text",VALEUR2,NULL);
   gtk_tree_view_append_column(GTK_TREE_VIEW(AZtreeview), column);}
  
store=gtk_list_store_new(COLUMNS2, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);
f2=fopen("AZrecherche.bin", "rb");
if(f2==NULL)
{
 return;
}
else 
{ f2=fopen("AZrecherche.bin", "ab+");
    while(fread(&c,sizeof(CAPTEURS),1,f2))
     {sprintf(Date,"%d/%d/%d",c.date.jour,c.date.mois,c.date.annee);
gtk_list_store_append (store,&iter);
gtk_list_store_set (store,&iter,TYPE2,c.type,IDENTIFIANT2,c.identifiant,MARQUE,c.marque,DATE2,Date,VALEUR2,c.valeur, -1);
}
fclose(f2);
gtk_tree_view_set_model (GTK_TREE_VIEW (AZtreeview), GTK_TREE_MODEL (store));
g_object_unref (store);
}
}
int nombret(CAPTEURS c)
{
int t=0;
float max1=45, min1=0;

FILE *f;
f = fopen("capteurs.bin", "rb");
while (fread(&c,sizeof(c),1,f)){
if((strcmp(c.type,"temperature")==0)&&((atoi(c.valeur)<min1) || (atoi(c.valeur)>max1)))
t=t+1;


}fclose(f);

return t;
} 
int Mrq_Deff(CAPTEURS c){

int n=0,m=0,p=0,z=0,res=0,x=0;
float max1=45,max2=300,min1=0,min2=10;
FILE *f;
f = fopen("capteurs.bin", "rb");
if(f!=NULL){
while (fread(&c,sizeof(c),1,f)){

	if(strcmp("marque1",c.marque)==0)
	{
	   if( ((strcmp(c.type,"temperature")==0)&&((atoi(c.valeur)<min1) || (atoi(c.valeur)>max1)))||			((strcmp(c.type,"humidite")==0)&&((atoi(c.valeur)<min2) || (atoi(c.valeur)>max2))) ){n++;}
	}
        else if(strcmp("marque2",c.marque)==0)
	{
	   if( ((strcmp(c.type,"temperature")==0)&&((atoi(c.valeur)<min1) || (atoi(c.valeur)>max1)))||((strcmp(c.type,"humidite")==0)&&((atoi(c.valeur)<min2) || (atoi(c.valeur)>max2))) ){m++;}
	}
        else if(strcmp("marque3",c.marque)==0)
	{
	   if( ((strcmp(c.type,"temperature")==0)&&((atoi(c.valeur)<min1) || (atoi(c.valeur)>max1)))||((strcmp(c.type,"humidite")==0)&&((atoi(c.valeur)<min2) || (atoi(c.valeur)>max2))) ){p++;}
	}
        else if(strcmp("marque4",c.marque)==0)
	{
	   if( ((strcmp(c.type,"temperature")==0)&&((atoi(c.valeur)<min1) || (atoi(c.valeur)>max1)))||((strcmp(c.type,"humidite")==0)&&((atoi(c.valeur)<min2) || (atoi(c.valeur)>max2))) ){z++;}
	}
	
}
}
fclose(f);
if(n>=m && p>=z && n>=p){res=n;}
else if(n>=m && p>=z && n<=p){res=p;}
else if(n<=m && p<=z && m>=z){res=m;}
else {res=z;}

if (res==n){x=1;}
else if (res==m){x=2;}
else if (res==p){x=3;}
else {x=4;}
return x;}
//....................................................................................
int nombreh(CAPTEURS c)
{
int h=0;
float max2=300 ,  min2=10;

FILE *f;
f = fopen("capteurs.bin", "rb");
while (fread(&c,sizeof(c),1,f)){

if((strcmp(c.type,"humidite")==0)&&((atoi(c.valeur)<min2 )|| (atoi(c.valeur)>max2)))
h=h+1;
}
fclose(f);

return h;
}

void affichagestat(GtkWidget* stattreeview)
{
float max1=45, min1=0,max2=300 ,  min2=10;
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;
CAPTEURS c;char Date[100];
store=NULL;
FILE *f;
store=gtk_tree_view_get_model(stattreeview);
if (store==NULL)
{
renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Type", renderer, "text",TYPEC, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (stattreeview), column);


renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Identifiant", renderer, "text",IDENTIFIANTC, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (stattreeview), column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Marque", renderer, "text",MARQUEC, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (stattreeview), column);

renderer=gtk_cell_renderer_text_new();
   column= gtk_tree_view_column_new_with_attributes("Valeur",renderer, "text",VALEURC,NULL);
   gtk_tree_view_append_column(GTK_TREE_VIEW(stattreeview), column);}

store=gtk_list_store_new(COLUMNSC,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
f=fopen("capteurs.bin","rb");
if(f==NULL)
{return;}
else
{f=fopen("capteurs.bin","ab+");
while(fread(&c,sizeof(CAPTEURS),1,f))
{
if( ((strcmp(c.type,"temperature")==0)&&((atoi(c.valeur)<min1) || (atoi(c.valeur)>max1)))||((strcmp(c.type,"humidite")==0)&&((atoi(c.valeur)<min2) || (atoi(c.valeur)>max2))) )
{
gtk_list_store_append(store,&iter);
gtk_list_store_set(store,&iter,TYPEC,c.type,IDENTIFIANTC,c.identifiant,MARQUEC,c.marque,VALEURC,c.valeur,-1);
}}
fclose(f);
gtk_tree_view_set_model(GTK_TREE_VIEW(stattreeview),GTK_TREE_MODEL (store));
g_object_unref(store);}}
//--------------------------------------------------------TROUPEAUX----------------------------------------------------------
enum{TYPE3,IDENTIFIANT3,SEXE3,DATE3,POIDS3,COLUMNS3};

void WMaffichage(GtkWidget* WMtreeview)
{
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;
ANIMAL a;char Date[100];
store=NULL;
FILE *f;
store=gtk_tree_view_get_model(WMtreeview);
if (store==NULL)
{
renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Type", renderer, "text",TYPE3, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (WMtreeview), column);


renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Identifiant", renderer, "text",IDENTIFIANT3, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (WMtreeview), column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Sexe", renderer, "text",SEXE3, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (WMtreeview), column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Date", renderer, "text",DATE3, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (WMtreeview), column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Poids", renderer, "text",POIDS3, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (WMtreeview), column);}

store=gtk_list_store_new(COLUMNS3,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
f=fopen("animaux.bin","rb");
if(f==NULL)
{return;}
else
{f=fopen("animaux.bin","ab+");
while(fread(&a,sizeof(ANIMAL),1,f))
{sprintf(Date,"%d/%d/%d",a.date.jour,a.date.mois,a.date.annee);
gtk_list_store_append(store,&iter);
gtk_list_store_set(store,&iter,TYPE3,a.type,IDENTIFIANT3,a.identifiant,SEXE3,a.sexe,DATE3,Date,POIDS3,a.poids,-1);
}
fclose(f);
gtk_tree_view_set_model(GTK_TREE_VIEW(WMtreeview),GTK_TREE_MODEL (store));
g_object_unref(store);}}




void WMajout (ANIMAL a){
FILE*f=NULL; 
f=fopen("animaux.bin","ab+");
fwrite(&a,sizeof(ANIMAL),1,f);  
fclose(f);
 
}


void WMsuppression(char id[30],ANIMAL a){
FILE*f;
FILE*g;
f=fopen("animaux.bin","rb+");
g=fopen("WMtmp.bin","wb+");
if(g!=NULL){
while(fread(&a,sizeof(ANIMAL),1,f))
{
if (strcmp(a.identifiant,id)!=0){
fwrite(&a,sizeof(ANIMAL),1,g);

}
}
}fclose(f);
fclose(g);
remove("animaux.bin");
rename("WMtmp.bin","animaux.bin");
}



void WMmodification(char id[30],ANIMAL a)
{

	WMsuppression(id,a);
	WMajout(a);

}

void WMrecherche(GtkWidget* WMtreeview)
{
GtkCellRenderer *renderer;
 GtkTreeViewColumn *column;
 GtkTreeIter iter;
 GtkListStore *store;

store=NULL;ANIMAL a;
 FILE *f2;char Date[100]; 
 store=gtk_tree_view_get_model(WMtreeview);
 if (store==NULL)
{

   renderer=gtk_cell_renderer_text_new();
   column= gtk_tree_view_column_new_with_attributes("Type",renderer, "text",TYPE3,NULL);
   gtk_tree_view_append_column(GTK_TREE_VIEW(WMtreeview), column);
 
   renderer=gtk_cell_renderer_text_new();
   column= gtk_tree_view_column_new_with_attributes("Identifiant",renderer, "text",IDENTIFIANT3,NULL);
   gtk_tree_view_append_column(GTK_TREE_VIEW(WMtreeview), column);
  
   renderer=gtk_cell_renderer_text_new();
   column= gtk_tree_view_column_new_with_attributes("Sexe",renderer, "text",SEXE3,NULL);
   gtk_tree_view_append_column(GTK_TREE_VIEW(WMtreeview), column);
   
   renderer=gtk_cell_renderer_text_new();
   column= gtk_tree_view_column_new_with_attributes("Date",renderer, "text",DATE3,NULL);
   gtk_tree_view_append_column(GTK_TREE_VIEW(WMtreeview), column);
   
   renderer=gtk_cell_renderer_text_new();
   column= gtk_tree_view_column_new_with_attributes("Poids",renderer, "text",POIDS3,NULL);
   gtk_tree_view_append_column(GTK_TREE_VIEW(WMtreeview), column);}
  
store=gtk_list_store_new(COLUMNS3, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);
f2=fopen("WMrecherche.bin", "rb");
if(f2==NULL)
{
 return;
}
else 
{ f2=fopen("WMrecherche.bin", "ab+");
    while(fread(&a,sizeof(ANIMAL),1,f2))
     {sprintf(Date,"%d/%d/%d",a.date.jour,a.date.mois,a.date.annee);
gtk_list_store_append (store,&iter);
gtk_list_store_set (store,&iter,TYPE,a.type,IDENTIFIANT3,a.identifiant,SEXE3,a.sexe,DATE3,Date,POIDS3,a.poids, -1);
}
fclose(f2);
gtk_tree_view_set_model (GTK_TREE_VIEW (WMtreeview), GTK_TREE_MODEL (store));
g_object_unref (store);
}
}

void nombre(int *b,int *v)
{
FILE *f;
ANIMAL a;
f = fopen("animaux.bin", "rb");
while (fread(&a,sizeof(a),1,f))
if(strcmp(a.type,"Brebi")==0)
*b+=1;
else
if(strcmp(a.type,"Veau")==0)
*v+=1;

fclose(f);


} 

//----------------------------------------------------EQUIPEMENTS---------------------------------------------------------------

enum{TYPE4,IDENTIFIANT4,NOMBRE4,DATE4,COM,COLUMNS4};

void Eaffichage(GtkWidget* Etreeview)
{
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;
EQUIP e;char Date[100];
store=NULL;
FILE *f;
store=gtk_tree_view_get_model(Etreeview);
if (store==NULL)
{
renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Type", renderer, "text",TYPE4, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (Etreeview), column);


renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Identifiant", renderer, "text",IDENTIFIANT4, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (Etreeview), column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Nombre", renderer, "text",NOMBRE4, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (Etreeview), column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Date", renderer, "text",DATE4, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (Etreeview), column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Commentaire", renderer, "text",COM, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (Etreeview), column);}

store=gtk_list_store_new(COLUMNS4,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
f=fopen("equipements.bin","rb");
if(f==NULL)
{return;}
else
{f=fopen("equipements.bin","ab+");
while(fread(&e,sizeof(EQUIP),1,f))
{sprintf(Date,"%d/%d/%d",e.date.jour,e.date.mois,e.date.annee);
gtk_list_store_append(store,&iter);
gtk_list_store_set(store,&iter,TYPE4,e.type,IDENTIFIANT4,e.identifiant,NOMBRE4,e.nombre,DATE4,Date,COM,e.com,-1);
}
fclose(f);
gtk_tree_view_set_model(GTK_TREE_VIEW(Etreeview),GTK_TREE_MODEL (store));
g_object_unref(store);}}



void Eajout (EQUIP e){
FILE*f=NULL; 
f=fopen("equipements.bin","ab+");
fwrite(&e,sizeof(EQUIP),1,f);  
fclose(f);
 
}
void Esuppression(char id[30],EQUIP e){
FILE*f;
FILE*g;
f=fopen("equipements.bin","rb+");
g=fopen("Etmp.bin","wb+");
if(g!=NULL){
while(fread(&e,sizeof(EQUIP),1,f))
{
if (strcmp(e.identifiant,id)!=0){
fwrite(&e,sizeof(EQUIP),1,g);

}
}
}fclose(f);
fclose(g);
remove("equipements.bin");
rename("Etmp.bin","equipements.bin");
}


void Emodification(char id[30],EQUIP e)
{

	Esuppression(id,e);
	Eajout(e);

}

void Erecherche(GtkWidget* Etreeview)
{
GtkCellRenderer *renderer;
 GtkTreeViewColumn *column;
 GtkTreeIter iter;
 GtkListStore *store;

store=NULL;EQUIP e;
 FILE *f2;char Date[100]; 
 store=gtk_tree_view_get_model(Etreeview);
 if (store==NULL)
{

   renderer=gtk_cell_renderer_text_new();
   column= gtk_tree_view_column_new_with_attributes("Type",renderer, "text",TYPE4,NULL);
   gtk_tree_view_append_column(GTK_TREE_VIEW(Etreeview), column);
 
   renderer=gtk_cell_renderer_text_new();
   column= gtk_tree_view_column_new_with_attributes("Identifiant",renderer, "text",IDENTIFIANT4,NULL);
   gtk_tree_view_append_column(GTK_TREE_VIEW(Etreeview), column);
  
   renderer=gtk_cell_renderer_text_new();
   column= gtk_tree_view_column_new_with_attributes("Nombre",renderer, "text",NOMBRE4,NULL);
   gtk_tree_view_append_column(GTK_TREE_VIEW(Etreeview), column);
   
   renderer=gtk_cell_renderer_text_new();
   column= gtk_tree_view_column_new_with_attributes("Date",renderer, "text",DATE4,NULL);
   gtk_tree_view_append_column(GTK_TREE_VIEW(Etreeview), column);
   
   renderer=gtk_cell_renderer_text_new();
   column= gtk_tree_view_column_new_with_attributes("Commentaire",renderer, "text",COM,NULL);
   gtk_tree_view_append_column(GTK_TREE_VIEW(Etreeview), column);}
  
store=gtk_list_store_new(COLUMNS4, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);
f2=fopen("Erecherche.bin", "rb");
if(f2==NULL)
{
 return;
}
else 
{ f2=fopen("Erecherche.bin", "ab+");
    while(fread(&e,sizeof(EQUIP),1,f2))
     {sprintf(Date,"%d/%d/%d",e.date.jour,e.date.mois,e.date.annee);
gtk_list_store_append (store,&iter);
gtk_list_store_set (store,&iter,TYPE4,e.type,IDENTIFIANT4,e.identifiant,NOMBRE4,e.nombre,DATE4,Date,COM,e.com, -1);
}
fclose(f2);
gtk_tree_view_set_model (GTK_TREE_VIEW (Etreeview), GTK_TREE_MODEL (store));
g_object_unref (store);
}
}
//------------------------------------------------------CLIENTS------------------------------------------------------------------
enum{NP5,IDENTIFIANT5,SEXE5,DATE5,VALEUR5,COLUMNS5};

void KKaffichage(GtkWidget* KKtreeview)
{
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;
CLIENT c;char Date[100];
store=NULL;
FILE *f;
store=gtk_tree_view_get_model(KKtreeview);
if (store==NULL)
{
renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Nom et Prenom", renderer, "text",NP5, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (KKtreeview), column);


renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Identifiant", renderer, "text",IDENTIFIANT5, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (KKtreeview), column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Sexe", renderer, "text",SEXE5, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (KKtreeview), column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Date", renderer, "text",DATE5, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (KKtreeview), column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Valeur des achats", renderer, "text",VALEUR5, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (KKtreeview), column);}

store=gtk_list_store_new(COLUMNS5,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
f=fopen("clients.bin","rb");
if(f==NULL)
{return;}
else
{f=fopen("clients.bin","ab+");
while(fread(&c,sizeof(CLIENT),1,f))
{sprintf(Date,"%d/%d/%d",c.date.jour,c.date.mois,c.date.annee);
gtk_list_store_append(store,&iter);
gtk_list_store_set(store,&iter,NP5,c.np,IDENTIFIANT5,c.identifiant,SEXE5,c.sexe,DATE5,Date,VALEUR5,c.valeur,-1);
}
fclose(f);
gtk_tree_view_set_model(GTK_TREE_VIEW(KKtreeview),GTK_TREE_MODEL (store));
g_object_unref(store);}}



void KKajout (CLIENT c){
FILE*f=NULL; 
f=fopen("clients.bin","ab+");
fwrite(&c,sizeof(CLIENT),1,f);  
fclose(f);
 
}


void KKsuppression(char id[30],CLIENT c){
FILE*f;
FILE*g;
f=fopen("clients.bin","rb+");
g=fopen("KKtmp.bin","wb+");
if(g!=NULL){
while(fread(&c,sizeof(CLIENT),1,f))
{
if (strcmp(c.identifiant,id)!=0){
fwrite(&c,sizeof(CLIENT),1,g);

}
}
}fclose(f);
fclose(g);
remove("clients.bin");
rename("KKtmp.bin","clients.bin");
}



void KKmodification(char id[30],CLIENT c)
{

	KKsuppression(id,c);
	KKajout(c);

}

void KKrecherche(GtkWidget* KKtreeview)
{
GtkCellRenderer *renderer;
 GtkTreeViewColumn *column;
 GtkTreeIter iter;
 GtkListStore *store;

store=NULL;CLIENT c;
 FILE *f2;char Date[100]; 
 store=gtk_tree_view_get_model(KKtreeview);
 if (store==NULL)
{
renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Nom et Prenom", renderer, "text",NP5, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (KKtreeview), column);


renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Identifiant", renderer, "text",IDENTIFIANT5, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (KKtreeview), column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Sexe", renderer, "text",SEXE5, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (KKtreeview), column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Date", renderer, "text",DATE5, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (KKtreeview), column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("Valeur des achats", renderer, "text",VALEUR5, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (KKtreeview), column);}
  
store=gtk_list_store_new(COLUMNS5, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);
f2=fopen("KKrecherche.bin", "rb");
if(f2==NULL)
{
 return;
}
else 
{ f2=fopen("KKrecherche.bin", "ab+");
    while(fread(&c,sizeof(CLIENT),1,f2))
     {sprintf(Date,"%d/%d/%d",c.date.jour,c.date.mois,c.date.annee);
gtk_list_store_append (store,&iter);
gtk_list_store_set(store,&iter,NP5,c.np,IDENTIFIANT5,c.identifiant,SEXE5,c.sexe,DATE5,Date,VALEUR5,c.valeur,-1);
}
fclose(f2);
gtk_tree_view_set_model (GTK_TREE_VIEW (KKtreeview), GTK_TREE_MODEL (store));
g_object_unref (store);
}
}
//------------------------------------------------------------LOGIN-------------------------------------------------------------

int verifl (insc in )
{
FILE*f; 
int x=0 ; 
insc i ; 
f=fopen("insc.bin","ab+");
if(f!=NULL)
{
while(fread(&i,sizeof(insc),1,f))
{
if (strcmp(i.uname,in.uname)==0) {x=1 ;}
}

fclose(f);
}
return x ; 
 
}


void inscription(insc i){
FILE*f; 
f=fopen("insc.bin","ab+");
fwrite(&i,sizeof(insc),1,f);  
fclose(f);
 
}



int veriflogin(auth a)
{
FILE*f; 
int x=0 ; 
insc i ; 
f=fopen("insc.bin","ab+");
if(f!=NULL)
{
while(fread(&i,sizeof(insc),1,f))
{
if ((strcmp(a.auname,i.uname)==0) && (strcmp(a.apass,i.password)==0))
{

if ((strcmp(i.role,"client")==0) || (strcmp(i.role,"Client")==0)) {x=6 ; }
if ((strcmp(i.role,"RO")==0) || (strcmp(i.role,"ro")==0)) {x=1 ;}
if ((strcmp(i.role,"RP")==0) || (strcmp(i.role,"rp")==0)) {x=2 ; }
if ((strcmp(i.role,"RA")==0) || (strcmp(i.role,"ra")==0)) {x=3 ;}
if ((strcmp(i.role,"RC")==0) || (strcmp(i.role,"rc")==0)) {x=4 ; }
if ((strcmp(i.role,"RE")==0) || (strcmp(i.role,"re")==0)) {x=5; }
if ((strcmp(i.role,"admin")==0) || (strcmp(i.role,"Admin")==0)) {x=7; }

}
}
}
fclose(f);
return x ; 
}

