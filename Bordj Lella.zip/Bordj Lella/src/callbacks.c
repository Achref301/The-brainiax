#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include"fichier.h"

//----------------------------------------------------------DÉCLARATIONS--------------------------------------------------------
char id[30],idrech[30],in[30];int v=0 ; 
GtkWidget *windowplantation;
GtkWidget *windowcapteur;
GtkWidget *windowtroupeau;
GtkWidget *windowclient;
GtkWidget *windowequipement;
GtkWidget *windowouvrier;
GtkWidget *windowstatistique;
GtkWidget *windowinscription;
GtkWidget *windowlogin;
GtkWidget *windowacceuil;
GtkWidget *windowadmin;
//----------------------------------------------------------PLANTATIONS----------------------------------------------------------
void
on_ASbuttonmenup_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
          windowplantation = lookup_widget(button,"windowplantation");
          gtk_widget_destroy(windowplantation);
          windowlogin = create_windowlogin();
          gtk_widget_show(windowlogin);
}


void
on_AStreeview_row_activated            (GtkTreeView     *AStreeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
	gchar* identifiant;
	GtkTreeModel *Model = gtk_tree_view_get_model(AStreeview);

		if (gtk_tree_model_get_iter(Model, &iter, path)){
				gtk_tree_model_get(GTK_LIST_STORE(Model),&iter,1,&identifiant, -1);
				strcpy(id,identifiant);}
}


void
on_ASbuttonrechercher_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
PLANTE p;
GtkWidget *windowplantation;
GtkWidget *ASentryid;
GtkWidget *AStreeview;
GtkWidget *alert2;
FILE*f;
FILE*f2;
alert2=lookup_widget(button, "ASlabelalertrech");
windowplantation=lookup_widget(button,"windowplantation");
ASentryid=lookup_widget(button,"ASentryid");
strcpy(idrech,gtk_entry_get_text(GTK_ENTRY(ASentryid)));
if (verif(idrech)==0){gtk_label_set_text(GTK_LABEL(alert2),"Champs obligatoire!");}
else if (verif(idrech)==1){
f=fopen("plantations.bin","rb");

 if(f!=NULL)
 {
  while(fread(&p,sizeof(PLANTE),1,f))
     {
       f2=fopen("ASrecherche.bin","ab+");
       if  (f2!=NULL)
   {  
     
     if (((strcmp(p.identifiant,idrech)==0))||((strcmp(p.type,idrech)==0)))
     { 
     fwrite(&p,sizeof(PLANTE),1,f2);
     }
   
     AStreeview=lookup_widget(windowplantation,"AStreeview");
     ASrecherche(AStreeview);
    
        fclose(f2);
    }

 }
 fclose(f);
}
remove("ASrecherche.bin");}
}


void
on_ASbuttongoajouter_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
	gtk_notebook_next_page(GTK_NOTEBOOK(lookup_widget(windowplantation,"ASnotebook")));
}

void
on_ASbuttonactualiser_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *AStreeview;
windowplantation=lookup_widget(button,"windowplantation");
AStreeview=lookup_widget(windowplantation,"AStreeview");
ASaffichage(AStreeview);
}


void
on_ASbuttonsupprimer_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
PLANTE p;
	    GtkWidget *AStreeview;
	    windowplantation=lookup_widget(button,"windowplantation");
	    AStreeview=lookup_widget(windowplantation,"AStreeview");
	    ASsuppression(id,p);
            ASaffichage(AStreeview);
}


void
on_ASbuttongomodifier_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *ASentrymodifid;
		ASentrymodifid=lookup_widget(button,"ASentrymodifid");
                gtk_notebook_next_page(GTK_NOTEBOOK(lookup_widget(windowplantation,"ASnotebook")));
                gtk_notebook_next_page(GTK_NOTEBOOK(lookup_widget(windowplantation,"ASnotebook")));	
		gtk_entry_set_text(GTK_ENTRY(ASentrymodifid),id);
}


void
on_ASbuttonboard_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
		gtk_notebook_next_page(GTK_NOTEBOOK(lookup_widget(windowplantation,"ASnotebook")));
                gtk_notebook_next_page(GTK_NOTEBOOK(lookup_widget(windowplantation,"ASnotebook")));
		gtk_notebook_next_page(GTK_NOTEBOOK(lookup_widget(windowplantation,"ASnotebook")));
}


void
on_ASbuttonajouter_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
char Type[30];char x[30];
PLANTE p;
GtkWidget *ASentryajoutid;
GtkWidget *ASspinbuttonajoutnbr;
GtkWidget *ASspinbuttonajoutrecolte;
GtkWidget *ASspinbuttonajoutjour;
GtkWidget *ASspinbuttonajoutmois;
GtkWidget *ASspinbuttonajoutannee;
GtkWidget *AScomboboxajouttype;
GtkWidget *sortiea;
GtkWidget *alert1;


ASspinbuttonajoutjour=lookup_widget(button, "ASspinbuttonajoutjour");
ASspinbuttonajoutmois=lookup_widget(button, "ASspinbuttonajoutmois");
ASspinbuttonajoutannee=lookup_widget(button, "ASspinbuttonajoutannee");
AScomboboxajouttype=lookup_widget(button, "AScomboboxajouttype");
ASentryajoutid=lookup_widget(button,"ASentryajoutid");
ASspinbuttonajoutnbr=lookup_widget(button, "ASspinbuttonajoutnbr");
ASspinbuttonajoutrecolte=lookup_widget(button, "ASspinbuttonajoutrecolte");
sortiea=lookup_widget(button, "ASlabelmsgsucc");
alert1=lookup_widget(button, "ASlabelajoutalertid");

strcpy(x,gtk_entry_get_text(GTK_ENTRY(ASentryajoutid)));
if (verif(x)==0){gtk_label_set_text(GTK_LABEL(alert1),"Champs obligatoire!");}
else if (verif(x)==1){
	if(verifid(x)==0){gtk_label_set_text(GTK_LABEL(alert1),"ID existe déjà");}

	else if(verifid(x)==1){
strcpy(p.identifiant,gtk_entry_get_text(GTK_ENTRY(ASentryajoutid)));
p.nombre=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(ASspinbuttonajoutnbr));
p.recolte=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(ASspinbuttonajoutrecolte));
p.date.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(ASspinbuttonajoutjour));
p.date.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(ASspinbuttonajoutmois));
p.date.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(ASspinbuttonajoutannee));

strcpy(Type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(AScomboboxajouttype)));
strcpy(p.type,Type);
ASajout(p);
gtk_label_set_text(GTK_LABEL(sortiea),"Ajout effectué avec succès!");}}
}


void
on_ASbuttonmodifier_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
PLANTE p;char Type[30];
GtkWidget *AScomboboxmodiftype;
GtkWidget *ASentrymodifid;
GtkWidget *ASspinbuttonmodifnbr;
GtkWidget *ASspinbuttonmodifjour;
GtkWidget *ASspinbuttonmodifmois;
GtkWidget *ASspinbuttonmodifannee;
GtkWidget *ASspinbuttonmodifrecolte;
GtkWidget *sortiem;    
	
ASspinbuttonmodifjour=lookup_widget(button, "ASspinbuttonmodifjour");
ASspinbuttonmodifmois=lookup_widget(button, "ASspinbuttonmodifmois");
ASspinbuttonmodifannee=lookup_widget(button, "ASspinbuttonmodifannee");
AScomboboxmodiftype=lookup_widget(button, "AScomboboxmodiftype");
ASentrymodifid=lookup_widget(button,"ASentrymodifid");
ASspinbuttonmodifnbr=lookup_widget(button, "ASspinbuttonmodifnbr");
ASspinbuttonmodifrecolte=lookup_widget(button, "ASspinbuttonmodifrecolte");
sortiem=lookup_widget(button, "ASlabelmodifreus");




strcpy(p.identifiant,gtk_entry_get_text(GTK_ENTRY(ASentrymodifid)));
p.nombre=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(ASspinbuttonmodifnbr));
p.recolte=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(ASspinbuttonmodifrecolte));
p.date.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(ASspinbuttonmodifjour));
p.date.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(ASspinbuttonmodifmois));
p.date.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(ASspinbuttonmodifannee));
strcpy(Type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(AScomboboxmodiftype)));
strcpy(p.type,Type);
ASmodification(id,p);
gtk_label_set_text(GTK_LABEL(sortiem),"Modification effectuée avec succès!");
}


void
on_ASbuttonseche_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *laba,*labr;
PLANTE p;
int a,r ; 
char seche[100] ; 
char rec[100];  


laba=lookup_widget(button,"ASlabela");
labr=lookup_widget(button,"ASlabelr");

a=anneeseche(p) ; 
r=recoltemin(p) ; 

sprintf(seche,"%d",a);
sprintf(rec,"%d",r);

gtk_label_set_text(GTK_LABEL(laba),seche);
gtk_label_set_text(GTK_LABEL(labr),rec);
}

//------------------------------------------------OUVRIER-------------------------------------------------------------
void
on_FMtreeview_row_activated            (GtkTreeView     *FMtreeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
	gchar* identifiant;
	GtkTreeModel *Model = gtk_tree_view_get_model(FMtreeview);

		if (gtk_tree_model_get_iter(Model, &iter, path)){
				gtk_tree_model_get(GTK_LIST_STORE(Model),&iter,1,&identifiant, -1);
				strcpy(id,identifiant);}
}


void
on_FMbuttonrechercher_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
ouvrier o;
GtkWidget *FMentryidrech;
GtkWidget *FMtreeview;
FILE*f;
FILE*f2;
windowouvrier=lookup_widget(button,"windowouvrier");
FMentryidrech=lookup_widget(button,"FMentryidrech");
strcpy(idrech,gtk_entry_get_text(GTK_ENTRY(FMentryidrech)));


     FMtreeview=lookup_widget(windowouvrier,"FMtreeview");
     //FMrecherche(FMtreeview,idrech);
f=fopen("ouvrier.bin","rb");
if(f!=NULL)
 {
  while(fread(&o,sizeof(ouvrier),1,f))
     {
       f2=fopen("FMrecherche.bin","ab+");
       if  (f2!=NULL)
 {  
     
     if (((strcmp(o.identifiant,idrech)==0))||((strcmp(o.sexe,idrech)==0))||((strcmp(o.cin,idrech)==0)))
     { 
     fwrite(&o,sizeof(ouvrier),1,f2);
     }
   
     FMtreeview=lookup_widget(windowouvrier,"FMtreeview");
     FMrecherche(FMtreeview,idrech);
    
        fclose(f2);
    }

 }
 fclose(f);
}
remove("FMrecherche.bin");
}



void
on_FMbuttonactualiser_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *FMtreeview,*FMtreeview2;
windowouvrier=lookup_widget(button,"windowouvrier");
FMtreeview=lookup_widget(windowouvrier,"FMtreeview");

FMtreeview2=lookup_widget(windowouvrier,"FMtreeview2");
FMaffichage(FMtreeview);
FMaffichageabs(FMtreeview2);
}


void
on_FMbuttonsupprimer_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
  GtkWidget *FMtreeview;
	    windowouvrier=lookup_widget(button,"windowouvrier");
	    FMtreeview=lookup_widget(windowouvrier,"FMtreeview");
	    FMsuppression(id);
            FMaffichage(FMtreeview);
}


void
on_FMbuttongoajouter_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
gtk_notebook_next_page(GTK_NOTEBOOK(lookup_widget(windowouvrier,"FMnotebook")));
}


void
on_FMbuttongomodifier_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
gtk_notebook_next_page(GTK_NOTEBOOK(lookup_widget(windowouvrier,"FMnotebook")));
                gtk_notebook_next_page(GTK_NOTEBOOK(lookup_widget(windowouvrier,"FMnotebook")));
}


void
on_FMbuttonpresence_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
		gtk_notebook_next_page(GTK_NOTEBOOK(lookup_widget(windowouvrier,"FMnotebook")));
                gtk_notebook_next_page(GTK_NOTEBOOK(lookup_widget(windowouvrier,"FMnotebook")));
		gtk_notebook_next_page(GTK_NOTEBOOK(lookup_widget(windowouvrier,"FMnotebook")));
               
}


void
on_FMbuttonajouter_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
char sexe[30];
ouvrier o;
GtkWidget *FMentryajoutidentifiant;
GtkWidget *FMentryajoutcin;
GtkWidget *FMentryajoutnumero;
GtkWidget *FMspinbuttonajoutjour;
GtkWidget *FMspinbuttonajoutmois;
GtkWidget *FMspinbuttonajoutannee;
GtkWidget *FMcomboboxajoutsexe;
GtkWidget *sortiea;

FMspinbuttonajoutjour=lookup_widget(button, "FMspinbuttonajoutjour");
FMspinbuttonajoutmois=lookup_widget(button, "FMspinbuttonajoutmois");
FMspinbuttonajoutannee=lookup_widget(button, "FMspinbuttonajoutannee");
FMcomboboxajoutsexe=lookup_widget(button, "FMcomboboxajoutsexe");
FMentryajoutidentifiant=lookup_widget(button,"FMentryajoutidentifiant");
FMentryajoutcin=lookup_widget(button,"FMentryajoutcin");
FMentryajoutnumero=lookup_widget(button,"FMentryajoutnumero");
sortiea=lookup_widget(button, "FMlabelajoutreus");

strcpy(o.identifiant,gtk_entry_get_text(GTK_ENTRY(FMentryajoutidentifiant)));
strcpy(o.cin,gtk_entry_get_text(GTK_ENTRY(FMentryajoutcin)));
strcpy(o.numtel,gtk_entry_get_text(GTK_ENTRY(FMentryajoutnumero)));
o.date.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(FMspinbuttonajoutjour));
o.date.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(FMspinbuttonajoutmois));
o.date.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(FMspinbuttonajoutannee));

strcpy(sexe,gtk_combo_box_get_active_text(GTK_COMBO_BOX(FMcomboboxajoutsexe)));
strcpy(o.sexe,sexe);
FMajout(o);
gtk_label_set_text(GTK_LABEL(sortiea),"Ajout effectué avec succès!");
}


void
on_FMbuttonmodifier_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
ouvrier ouv ;
char sexe[30];
GtkWidget *FMentrymodifidentifiant;
GtkWidget *FMentrymodifcin;
GtkWidget *FMentrymodifnumero;
GtkWidget *FMspinbuttonmodifjour;
GtkWidget *FMspinbuttonmodifmois;
GtkWidget *FMspinbuttonmodifannee;
GtkWidget *FMcomboboxmodifsexe;
GtkWidget *sortiem;
	
FMspinbuttonmodifjour=lookup_widget(button, "FMspinbuttonmodifjour");
FMspinbuttonmodifmois=lookup_widget(button, "FMspinbuttonmodifmois");
FMspinbuttonmodifannee=lookup_widget(button, "FMspinbuttonmodifannee");
FMcomboboxmodifsexe=lookup_widget(button, "FMcomboboxmodifsexe");
FMentrymodifidentifiant=lookup_widget(button,"FMentrymodifidentifiant");
FMentrymodifcin=lookup_widget(button,"FMentrymodifcin");
FMentrymodifnumero=lookup_widget(button,"FMentrymodifnumero");
sortiem=lookup_widget(button, "FMlabelmodifreus");
strcpy(id,gtk_entry_get_text(GTK_ENTRY(FMentrymodifidentifiant)));
strcpy(ouv.cin,gtk_entry_get_text(GTK_ENTRY(FMentrymodifcin)));
strcpy(ouv.numtel,gtk_entry_get_text(GTK_ENTRY(FMentrymodifnumero)));
ouv.date.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(FMspinbuttonmodifjour));
ouv.date.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(FMspinbuttonmodifmois));
ouv.date.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(FMspinbuttonmodifannee));

strcpy(sexe,gtk_combo_box_get_active_text(GTK_COMBO_BOX(FMcomboboxmodifsexe)));
strcpy(ouv.sexe,sexe);
FMmodification(id,ouv);

gtk_label_set_text(GTK_LABEL(sortiem),"Modification effectuée avec succès!");
}


void
on_FMtreeview2_row_activated           (GtkTreeView     *FMtreeview2,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
	gchar* identifiant;
	GtkTreeModel *Model = gtk_tree_view_get_model(FMtreeview2);

		if (gtk_tree_model_get_iter(Model, &iter, path)){
				gtk_tree_model_get(GTK_LIST_STORE(Model),&iter,0,&identifiant, -1);
				strcpy(id,identifiant);}

}


void
on_FMbuttonokpres_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *Ajout;
char etat[30];
ouvabs x;
GtkWidget *FMentrypresid;
GtkWidget *FMspinbuttonpresjour;
GtkWidget *FMspinbuttonpresmois;
GtkWidget *FMspinbuttonpresannee;
GtkWidget *FMcomboboxetat;
FMspinbuttonpresjour=lookup_widget(button, "FMspinbuttonpresjour");
FMspinbuttonpresmois=lookup_widget(button, "FMspinbuttonpresmois");
FMspinbuttonpresannee=lookup_widget(button, "FMspinbuttonpresannee");
FMcomboboxetat=lookup_widget(button, "FMcomboboxetat");
FMentrypresid=lookup_widget(button,"FMentrypresid");
strcpy(x.identifiant,gtk_entry_get_text(GTK_ENTRY(FMentrypresid)));
x.date.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(FMspinbuttonpresjour));
x.date.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(FMspinbuttonpresmois));
x.date.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(FMspinbuttonpresannee));

strcpy(etat,gtk_combo_box_get_active_text(GTK_COMBO_BOX(FMcomboboxetat)));
strcpy(x.etat,etat);
FMajoutpresence(x);

windowouvrier=lookup_widget(button,"windowouvrier");
Ajout =create_windowsuccess();	
	     
gtk_widget_hide(windowouvrier);
gtk_widget_show(Ajout);

}


void
on_FMbuttonpresafficher_clicked        (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *FMtreeview2;
windowouvrier=lookup_widget(button,"windowouvrier");
FMtreeview2=lookup_widget(windowouvrier,"FMtreeview2");
FMaffichageabs(FMtreeview2);
}


void
on_FMbuttonpressupp_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
ouvabs x;
 GtkWidget *Supp;
 windowouvrier=lookup_widget(button,"windowouvrier");
Supp =create_windowsuccess();	
	  
 FMsuppressionpresence(id,x);
          
gtk_widget_hide(windowouvrier);
gtk_widget_show(Supp);
}


void
on_FMbuttontaux_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *lab;
int t ; 
int nb ; 
char taux[20] ; 
char nbo[20];   


lab=lookup_widget(button,"FMlabeltaux");
t=tauxab() ; 
nb=nouvr() ;
  
sprintf(taux,"%d",t);
sprintf(nbo,"%d",nb);

strcat(taux,"/"); 
strcat(taux,nbo) ; 
 
gtk_label_set_text(GTK_LABEL(lab),taux);
}


void
on_FMbuttonokdialogue_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
ouvabs x;
 GtkWidget *Ajout,*FMtreeview2;
 Ajout=lookup_widget(button,"windowsuccess");
windowouvrier = create_windowouvrier();	
	          
gtk_widget_hide(Ajout);
gtk_widget_show(windowouvrier);
 FMtreeview2=lookup_widget(windowouvrier,"FMtreeview2");
	   
 FMaffichageabs(FMtreeview2);
}

//----------------------------------------------------CLIENTS---------------------------------------------------
void
on_KKtreeview_row_activated            (GtkTreeView     *KKtreeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
	gchar* identifiant;
	GtkTreeModel *Model = gtk_tree_view_get_model(KKtreeview);

		if (gtk_tree_model_get_iter(Model, &iter, path)){
				gtk_tree_model_get(GTK_LIST_STORE(Model),&iter,1,&identifiant, -1);
				strcpy(id,identifiant);}
}


void
on_KKbuttonrechercher_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
CLIENT c;
char idrech[30];
GtkWidget *KKentryid;
GtkWidget *KKtreeview;
FILE*f;
FILE*f2;


windowclient=lookup_widget(button,"windowclient");
KKentryid=lookup_widget(button,"KKentryid");
strcpy(idrech,gtk_entry_get_text(GTK_ENTRY(KKentryid)));
f=fopen("clients.bin","rb");

 if(f!=NULL)
 {
  while(fread(&c,sizeof(CLIENT),1,f))
     {
       f2=fopen("KKrecherche.bin","ab+");
       if  (f2!=NULL)
   {  
     
     if ((strcmp(c.np,idrech)==0) || (strcmp(c.identifiant,idrech)==0) || (strcmp(c.sexe,idrech)==0) || (strcmp(c.valeur,idrech)==0))
     { 
     fwrite(&c,sizeof(CLIENT),1,f2);
     }
   
     KKtreeview=lookup_widget(windowclient,"KKtreeview");
     KKrecherche(KKtreeview);
    
        fclose(f2);
    }

 }
 fclose(f);
}
remove("KKrecherche.bin");
}


void
on_KKbuttonactualiser_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *KKtreeview;
windowclient=lookup_widget(button,"windowclient");
KKtreeview=lookup_widget(windowclient,"KKtreeview");
KKaffichage(KKtreeview);
}


void
on_KKbuttonboard_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *max , *nomp ;
FILE *f;
CLIENT c;
float j;
char maxpaim[20];
char nomprenom[20];
float mp=0;
f=fopen ("clients.bin","rb");
while (fread (&c,sizeof (CLIENT),1,f)!=0)
{      
strcpy(maxpaim,c.valeur);
sscanf (maxpaim,"%f",&j);

if (j>mp){
	mp =j;
	strcpy(nomprenom,c.np);}

}
fclose (f);

max=lookup_widget (button,"labelmnp"); 
char *maxi = g_strdup_printf ("%f", mp);
gtk_label_set_text(GTK_LABEL(max),maxi);

nomp=lookup_widget (button,"labelme");  
gtk_label_set_text(GTK_LABEL(nomp),nomprenom);
}


void
on_KKbuttongomodifier_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
		gtk_notebook_next_page(GTK_NOTEBOOK(lookup_widget(windowclient,"KKnotebook")));
                gtk_notebook_next_page(GTK_NOTEBOOK(lookup_widget(windowclient,"KKnotebook")));		

	char Sexe[30];
	CLIENT c;		
	
	GtkWidget *KKcomboboxmodifsexe;
	GtkWidget *KKentrymodifid;
	GtkWidget *KKentrymodifnp;
	GtkWidget *KKspinbuttonmodifjour;
	GtkWidget *KKspinbuttonmodifmois;
	GtkWidget *KKspinbuttonmodifannee;
	GtkWidget *KKentrymodifvaleur;
	GtkWidget *sortiem;    
	
	KKspinbuttonmodifjour=lookup_widget(button, "KKspinbuttonmodifjour");
	KKspinbuttonmodifmois=lookup_widget(button, "KKspinbuttonmodifmois");
	KKspinbuttonmodifannee=lookup_widget(button, "KKspinbuttonmodifannee");
	KKcomboboxmodifsexe=lookup_widget(button, "KKcomboboxmodifsexe");
	KKentrymodifid=lookup_widget(button,"KKentrymodifid");
	KKentrymodifnp=lookup_widget(button,"KKentrymodifnp");
	KKentrymodifvaleur=lookup_widget(button,"KKentrymodifvaleur");

	
	gtk_spin_button_set_value(KKspinbuttonmodifjour,c.date.jour);
	gtk_spin_button_set_value(KKspinbuttonmodifmois,c.date.mois);
	gtk_spin_button_set_value(KKspinbuttonmodifannee,c.date.annee);
	
	gtk_entry_set_text(GTK_ENTRY(KKentrymodifid),c.identifiant);
	gtk_entry_set_text(GTK_ENTRY(KKentrymodifnp),c.np);
	gtk_entry_set_text(GTK_ENTRY(KKentrymodifvaleur),c.valeur);
}


void
on_KKbuttongoajouter_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
 	gtk_notebook_next_page(GTK_NOTEBOOK(lookup_widget(windowclient,"KKnotebook")));
}


void
on_KKbuttonsupprimer_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
CLIENT c;
	    GtkWidget *KKtreeview;
	    windowclient=lookup_widget(button,"windowclient");
	    KKtreeview=lookup_widget(windowclient,"KKtreeview");
	    KKsuppression(id,c);
            KKaffichage(KKtreeview);
}


void
on_KKbuttonajouter_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
char Sexe[30];
CLIENT c;
GtkWidget *KKentryajoutid;
GtkWidget *KKentryajoutnp;
GtkWidget *KKentryajoutvaleur;
GtkWidget *KKspinbuttonajoutjour;
GtkWidget *KKspinbuttonajoutmois;
GtkWidget *KKspinbuttonajoutannee;
GtkWidget *KKcomboboxajoutsexe;
GtkWidget *sortiea;

KKspinbuttonajoutjour=lookup_widget(button, "KKspinbuttonajoutjour");
KKspinbuttonajoutmois=lookup_widget(button, "KKspinbuttonajoutmois");
KKspinbuttonajoutannee=lookup_widget(button, "KKspinbuttonajoutannee");
KKcomboboxajoutsexe=lookup_widget(button, "KKcomboboxajoutsexe");
KKentryajoutid=lookup_widget(button,"KKentryajoutid");
KKentryajoutnp=lookup_widget(button,"KKentryajoutnp");
KKentryajoutvaleur=lookup_widget(button,"KKentryajoutvaleur");
sortiea=lookup_widget(button, "KKlabelajoutreus");

strcpy(c.identifiant,gtk_entry_get_text(GTK_ENTRY(KKentryajoutid)));
strcpy(c.np,gtk_entry_get_text(GTK_ENTRY(KKentryajoutnp)));
strcpy(c.valeur,gtk_entry_get_text(GTK_ENTRY(KKentryajoutvaleur)));
c.date.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(KKspinbuttonajoutjour));
c.date.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(KKspinbuttonajoutmois));
c.date.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(KKspinbuttonajoutannee));

strcpy(Sexe,gtk_combo_box_get_active_text(GTK_COMBO_BOX(KKcomboboxajoutsexe)));
strcpy(c.sexe,Sexe);
KKajout(c);
gtk_label_set_text(GTK_LABEL(sortiea),"Ajout effectué avec succès!");
}


void
on_KKbuttonmodifier_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
CLIENT c;
char Sexe[30];
GtkWidget *KKcomboboxmodifsexe;
GtkWidget *KKentrymodifid;
GtkWidget *KKentrymodifnp;
GtkWidget *KKspinbuttonmodifjour;
GtkWidget *KKspinbuttonmodifmois;
GtkWidget *KKspinbuttonmodifannee;
GtkWidget *KKentrymodifvaleur;
GtkWidget *sortiem;    
	
KKspinbuttonmodifjour=lookup_widget(button, "KKspinbuttonmodifjour");
KKspinbuttonmodifmois=lookup_widget(button, "KKspinbuttonmodifmois");
KKspinbuttonmodifannee=lookup_widget(button, "KKspinbuttonmodifannee");
KKcomboboxmodifsexe=lookup_widget(button, "KKcomboboxmodifsexe");
KKentrymodifid=lookup_widget(button,"KKentrymodifid");
KKentrymodifnp=lookup_widget(button,"KKentrymodifnp");
KKentrymodifvaleur=lookup_widget(button,"KKentrymodifvaleur");
sortiem=lookup_widget(button, "KKlabelmodifreus");

strcpy(c.identifiant,gtk_entry_get_text(GTK_ENTRY(KKentrymodifid)));
strcpy(c.np,gtk_entry_get_text(GTK_ENTRY(KKentrymodifnp)));
strcpy(c.valeur,gtk_entry_get_text(GTK_ENTRY(KKentrymodifvaleur)));
c.date.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(KKspinbuttonmodifjour));
c.date.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(KKspinbuttonmodifmois));
c.date.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(KKspinbuttonmodifannee));
strcpy(Sexe,gtk_combo_box_get_active_text(GTK_COMBO_BOX(KKcomboboxmodifsexe)));
strcpy(c.sexe,Sexe);
KKmodification(id,c);
gtk_label_set_text(GTK_LABEL(sortiem),"Modification effectuée avec succès!");
}

//------------------------------------------------------TROUPEAUX------------------------------------------------------
void
on_buttonmenucl_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
          windowclient = lookup_widget(button,"windowclient");
          gtk_widget_destroy(windowclient);
          windowlogin = create_windowlogin();
          gtk_widget_show(windowlogin);
}


void
on_buttonmenut_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
          windowtroupeau = lookup_widget(button,"windowtroupeau");
          gtk_widget_destroy(windowtroupeau);
          windowlogin = create_windowlogin();
          gtk_widget_show(windowlogin);
}


void
on_WMtreeview_row_activated            (GtkTreeView     *WMtreeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
	gchar* identifiant;
	GtkTreeModel *Model = gtk_tree_view_get_model(WMtreeview);

		if (gtk_tree_model_get_iter(Model, &iter, path)){
				gtk_tree_model_get(GTK_LIST_STORE(Model),&iter,1,&identifiant, -1);
				strcpy(id,identifiant);}
}


void
on_WMbuttonrechercher_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
ANIMAL a;
GtkWidget *WMentryid;
GtkWidget *WMtreeview;
FILE*f;
FILE*f2;


windowtroupeau=lookup_widget(button,"windowtroupeau");
WMentryid=lookup_widget(button,"WMentryid");
strcpy(idrech,gtk_entry_get_text(GTK_ENTRY(WMentryid)));
f=fopen("animaux.bin","rb");

 if(f!=NULL)
 {
  while(fread(&a,sizeof(ANIMAL),1,f))
     {
       f2=fopen("WMrecherche.bin","ab+");
       if  (f2!=NULL)
   {  
     
     if ((strcmp(a.identifiant,idrech)==0))
     { 
     fwrite(&a,sizeof(ANIMAL),1,f2);
     }
   
     WMtreeview=lookup_widget(windowtroupeau,"WMtreeview");
     WMrecherche(WMtreeview);
    
        fclose(f2);
    }

 }
 fclose(f);
}
remove("WMrecherche.bin");
}


void
on_WMbuttonactualiser_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *WMtreeview;
windowtroupeau=lookup_widget(button,"windowtroupeau");
WMtreeview=lookup_widget(windowtroupeau,"WMtreeview");
WMaffichage(WMtreeview);
}


void
on_WMbuttonsupprimer_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
ANIMAL a;
    GtkWidget *WMtreeview;
	    windowtroupeau=lookup_widget(button,"windowtroupeau");
	    WMtreeview=lookup_widget(windowtroupeau,"WMtreeview");
	    WMsuppression(id,a);
            WMaffichage(WMtreeview);
}


void
on_WMbuttongoajouter_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
gtk_notebook_next_page(GTK_NOTEBOOK(lookup_widget(windowtroupeau,"WMnotebook")));
}


void
on_WMbuttongomodifier_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
gtk_notebook_next_page(GTK_NOTEBOOK(lookup_widget(windowtroupeau,"WMnotebook")));
gtk_notebook_next_page(GTK_NOTEBOOK(lookup_widget(windowtroupeau,"WMnotebook")));
}


void
on_WMbuttonstatistique_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{
int *b,*v,a=0,c=0;
char chv[30],chb[30];
b=&a;
v=&c;
GtkWidget *labelBrebi;
GtkWidget *labelVeau;
ANIMAL e;
windowtroupeau = lookup_widget(button,"windowtroupeau");
gtk_widget_destroy(windowtroupeau);
windowstatistique = create_windowstatistique();
gtk_widget_show(windowstatistique);


labelBrebi=lookup_widget(windowstatistique,"labelb");
labelVeau=lookup_widget(windowstatistique,"labelv");
 nombre( b ,v);
sprintf(chb,"%d",a);
sprintf(chv,"%d",c);
gtk_label_set_text(labelBrebi,chb);
gtk_label_set_text(labelVeau,chv);
}


void
on_WMbuttonajouter_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
ANIMAL a;char Type[30];
GtkWidget *WMentryajoutid;
GtkWidget *WMentryajoutsexe;
GtkWidget *WMentryajoutpoids;
GtkWidget *WMspinbuttonajoutjour;
GtkWidget *WMspinbuttonajoutmois;
GtkWidget *WMspinbuttonajoutannee;
GtkWidget *WMcomboboxajouttype;
GtkWidget *sortiea;

WMspinbuttonajoutjour=lookup_widget(button, "WMspinbuttonajoutjour");
WMspinbuttonajoutmois=lookup_widget(button, "WMspinbuttonajoutmois");
WMspinbuttonajoutannee=lookup_widget(button, "WMspinbuttonajoutannee");
WMcomboboxajouttype=lookup_widget(button, "WMcomboboxajouttype");
WMentryajoutid=lookup_widget(button,"WMentryajoutid");
WMentryajoutsexe=lookup_widget(button,"WMentryajoutsexe");
WMentryajoutpoids=lookup_widget(button,"WMentryajoutpoids");
sortiea=lookup_widget(button, "WMlabelajoutreus");

strcpy(a.identifiant,gtk_entry_get_text(GTK_ENTRY(WMentryajoutid)));
strcpy(a.sexe,gtk_entry_get_text(GTK_ENTRY(WMentryajoutsexe)));
strcpy(a.poids,gtk_entry_get_text(GTK_ENTRY(WMentryajoutpoids)));
a.date.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(WMspinbuttonajoutjour));
a.date.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(WMspinbuttonajoutmois));
a.date.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(WMspinbuttonajoutannee));

strcpy(Type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(WMcomboboxajouttype)));
strcpy(a.type,Type);
WMajout(a);
gtk_label_set_text(GTK_LABEL(sortiea),"Ajout effectué avec succès!");
}


void
on_WMbuttonmodifier_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
ANIMAL a;char Type[30];
GtkWidget *WMcomboboxmodiftype;
GtkWidget *WMentrymodifid;
GtkWidget *WMentrymodifsexe;
GtkWidget *WMspinbuttonmodifjour;
GtkWidget *WMspinbuttonmodifmois;
GtkWidget *WMspinbuttonmodifannee;
GtkWidget *WMentrymodifpoids;
GtkWidget *sortiem;    
	
WMspinbuttonmodifjour=lookup_widget(button, "WMspinbuttonmodifjour");
WMspinbuttonmodifmois=lookup_widget(button, "WMspinbuttonmodifmois");
WMspinbuttonmodifannee=lookup_widget(button, "WMspinbuttonmodifannee");
WMcomboboxmodiftype=lookup_widget(button, "WMcomboboxmodiftype");
WMentrymodifid=lookup_widget(button,"WMentrymodifid");
WMentrymodifsexe=lookup_widget(button,"WMentrymodifsexe");
WMentrymodifpoids=lookup_widget(button,"WMentrymodifpoids");
sortiem=lookup_widget(button, "WMlabelmodifreus");

strcpy(a.identifiant,gtk_entry_get_text(GTK_ENTRY(WMentrymodifid)));
strcpy(a.sexe,gtk_entry_get_text(GTK_ENTRY(WMentrymodifsexe)));
strcpy(a.poids,gtk_entry_get_text(GTK_ENTRY(WMentrymodifpoids)));
a.date.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(WMspinbuttonmodifjour));
a.date.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(WMspinbuttonmodifmois));
a.date.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(WMspinbuttonmodifannee));
strcpy(Type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(WMcomboboxmodiftype)));
strcpy(a.type,Type);
WMmodification(id,a);
gtk_label_set_text(GTK_LABEL(sortiem),"Modification effectuée avec succès!");
}


void
on_WMbuttonretour_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
windowstatistique = lookup_widget(button,"windowstatistique");
gtk_widget_destroy(windowstatistique);
windowtroupeau = create_windowtroupeau();
gtk_widget_show(windowtroupeau);

}

//-------------------------------------------------------EQUIPEMENTS---------------------------------------------
void
on_buttonmenue_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
	  windowequipement = lookup_widget(button,"windowequipement");
          gtk_widget_destroy(windowequipement);
          windowlogin = create_windowlogin();
          gtk_widget_show(windowlogin);
}


void
on_Etreeview_row_activated             (GtkTreeView     *Etreeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
	gchar* identifiant;
	GtkTreeModel *Model = gtk_tree_view_get_model(Etreeview);

		if (gtk_tree_model_get_iter(Model, &iter, path)){
				gtk_tree_model_get(GTK_LIST_STORE(Model),&iter,1,&identifiant, -1);
				strcpy(id,identifiant);}
}


void
on_Ebuttonrechercher_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
EQUIP e;
GtkWidget *Eentryid;
GtkWidget *Etreeview;
FILE*f;
FILE*f2;


windowequipement=lookup_widget(button,"windowequipement");
Eentryid=lookup_widget(button,"Eentryid");
strcpy(idrech,gtk_entry_get_text(GTK_ENTRY(Eentryid)));
f=fopen("equipements.bin","rb");

 if(f!=NULL)
 {
  while(fread(&e,sizeof(EQUIP),1,f))
     {
       f2=fopen("Erecherche.bin","ab+");
       if  (f2!=NULL)
   {  
     
     if (((strcmp(e.identifiant,idrech)==0))||((strcmp(e.type,idrech)==0)))
     { 
     fwrite(&e,sizeof(EQUIP),1,f2);
     }
   
     Etreeview=lookup_widget(windowequipement,"Etreeview");
     Erecherche(Etreeview);
    
        fclose(f2);
    }

 }
 fclose(f);
}
remove("Erecherche.bin");
}


void
on_Ebuttonactualiser_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *Etreeview;
windowequipement=lookup_widget(button,"windowequipement");
Etreeview=lookup_widget(windowequipement,"Etreeview");
Eaffichage(Etreeview);
}


void
on_Ebuttonsupprimer_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
EQUIP e;
	    GtkWidget *Etreeview;
	    windowequipement=lookup_widget(button,"windowequipement");
	    Etreeview=lookup_widget(windowequipement,"Etreeview");
	    Esuppression(id,e);
            Eaffichage(Etreeview);
}


void
on_Ebuttongoajouter_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
gtk_notebook_next_page(GTK_NOTEBOOK(lookup_widget(windowequipement,"Enotebook")));
}


void
on_Ebuttongomodifier_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
gtk_notebook_next_page(GTK_NOTEBOOK(lookup_widget(windowequipement,"Enotebook")));
gtk_notebook_next_page(GTK_NOTEBOOK(lookup_widget(windowequipement,"Enotebook")));
}


void
on_Ebuttonajouter_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
char Type[30];
EQUIP e;
GtkWidget *Eentryajoutid;
GtkWidget *Eentryajoutnbr;
GtkWidget *Eentryajoutcom;
GtkWidget *Espinbuttonajoutjour;
GtkWidget *Espinbuttonajoutmois;
GtkWidget *Espinbuttonajoutannee;
GtkWidget *Ecomboboxajouttype;
GtkWidget *sortiea;

Espinbuttonajoutjour=lookup_widget(button, "Espinbuttonajoutjour");
Espinbuttonajoutmois=lookup_widget(button, "Espinbuttonajoutmois");
Espinbuttonajoutannee=lookup_widget(button, "Espinbuttonajoutannee");
Ecomboboxajouttype=lookup_widget(button, "Ecomboboxajouttype");
Eentryajoutid=lookup_widget(button,"Eentryajoutid");
Eentryajoutnbr=lookup_widget(button,"Eentryajoutnbr");
Eentryajoutcom=lookup_widget(button,"Eentryajoutcom");
sortiea=lookup_widget(button, "Elabelajoutreus");

strcpy(e.identifiant,gtk_entry_get_text(GTK_ENTRY(Eentryajoutid)));
strcpy(e.nombre,gtk_entry_get_text(GTK_ENTRY(Eentryajoutnbr)));
strcpy(e.com,gtk_entry_get_text(GTK_ENTRY(Eentryajoutcom)));
e.date.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Espinbuttonajoutjour));
e.date.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Espinbuttonajoutmois));
e.date.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Espinbuttonajoutannee));

strcpy(Type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(Ecomboboxajouttype)));
strcpy(e.type,Type);
Eajout(e);
gtk_label_set_text(GTK_LABEL(sortiea),"Ajout effectué avec succès!");
}


void
on_Ebuttonmodifier_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
EQUIP e; char Type[30];
GtkWidget *Ecomboboxmodiftype;
GtkWidget *Eentrymodifid;
GtkWidget *Eentrymodifnbr;
GtkWidget *Espinbuttonmodifjour;
GtkWidget *Espinbuttonmodifmois;
GtkWidget *Espinbuttonmodifannee;
GtkWidget *Eentrymodifcom;
GtkWidget *sortiem;    
	
Espinbuttonmodifjour=lookup_widget(button, "Espinbuttonmodifjour");
Espinbuttonmodifmois=lookup_widget(button, "Espinbuttonmodifmois");
Espinbuttonmodifannee=lookup_widget(button, "Espinbuttonmodifannee");
Ecomboboxmodiftype=lookup_widget(button, "Ecomboboxmodiftype");
Eentrymodifid=lookup_widget(button,"Eentrymodifid");
Eentrymodifnbr=lookup_widget(button,"Eentrymodifnbr");
Eentrymodifcom=lookup_widget(button,"Eentrymodifcom");
sortiem=lookup_widget(button, "Elabelmodifreus");

strcpy(e.identifiant,gtk_entry_get_text(GTK_ENTRY(Eentrymodifid)));
strcpy(e.nombre,gtk_entry_get_text(GTK_ENTRY(Eentrymodifnbr)));
strcpy(e.com,gtk_entry_get_text(GTK_ENTRY(Eentrymodifcom)));
e.date.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Espinbuttonmodifjour));
e.date.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Espinbuttonmodifmois));
e.date.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Espinbuttonmodifannee));
strcpy(Type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(Ecomboboxmodiftype)));
strcpy(e.type,Type);
Emodification(id,e);
gtk_label_set_text(GTK_LABEL(sortiem),"Modification effectuée avec succès!");
}

//-----------------------------------------------CAPTEUR---------------------------------------------------------------
void
on_buttonmenucp_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
          windowcapteur = lookup_widget(button,"windowcapteur");
          gtk_widget_destroy(windowcapteur);
          windowlogin = create_windowlogin();
          gtk_widget_show(windowlogin);
}


void
on_AZtreeview_row_activated            (GtkTreeView     *AZtreeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
	gchar* identifiant;
	GtkTreeModel *Model = gtk_tree_view_get_model(AZtreeview);

		if (gtk_tree_model_get_iter(Model, &iter, path)){
				gtk_tree_model_get(GTK_LIST_STORE(Model),&iter,1,&identifiant, -1);
				strcpy(id,identifiant);}
}


void
on_AZbuttonsupprimer_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
CAPTEURS c;
	    GtkWidget *AZtreeview;
	    windowcapteur=lookup_widget(button,"windowcapteur");
	    AZtreeview=lookup_widget(windowcapteur,"AZtreeview");
	    AZsuppression(id,c);
            AZaffichage(AZtreeview);
}


void
on_AZbuttonactualiser_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *AZtreeview;
windowcapteur=lookup_widget(button,"windowcapteur");
AZtreeview=lookup_widget(windowcapteur,"AZtreeview");
AZaffichage(AZtreeview);
}


void
on_AZbuttonrechercher_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
CAPTEURS c;
GtkWidget *AZentryid;
GtkWidget *AZtreeview;
FILE*f;
FILE*f2;


windowcapteur=lookup_widget(button,"windowcapteur");
AZentryid=lookup_widget(button,"AZentryid");
strcpy(idrech,gtk_entry_get_text(GTK_ENTRY(AZentryid)));
f=fopen("capteurs.bin","rb");

 if(f!=NULL)
 {
  while(fread(&c,sizeof(CAPTEURS),1,f))
     {
       f2=fopen("AZrecherche.bin","ab+");
       if  (f2!=NULL)
   {  
     
     if (((strcmp(c.identifiant,idrech)==0))||((strcmp(c.type,idrech)==0))||((strcmp(c.marque,idrech)==0)))
     { 
     fwrite(&c,sizeof(CAPTEURS),1,f2);
     }
   
     AZtreeview=lookup_widget(windowcapteur,"AZtreeview");
     AZrecherche(AZtreeview);
    
        fclose(f2);
    }

 }
 fclose(f);
}
remove("AZrecherche.bin");
}


void
on_AZbuttonboard_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
		gtk_notebook_next_page(GTK_NOTEBOOK(lookup_widget(windowcapteur,"AZnotebook")));
                gtk_notebook_next_page(GTK_NOTEBOOK(lookup_widget(windowcapteur,"AZnotebook")));
		gtk_notebook_next_page(GTK_NOTEBOOK(lookup_widget(windowcapteur,"AZnotebook")));
                
}


void
on_AZbuttongoajouter_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
		gtk_notebook_next_page(GTK_NOTEBOOK(lookup_widget(windowcapteur,"AZnotebook")));
}


void
on_AZbuttongomodifier_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
		gtk_notebook_next_page(GTK_NOTEBOOK(lookup_widget(windowcapteur,"AZnotebook")));
                gtk_notebook_next_page(GTK_NOTEBOOK(lookup_widget(windowcapteur,"AZnotebook")));
}


void
on_AZbuttonajouter_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
char Type[30];char Marque[30];
CAPTEURS c;
GtkWidget *AZentryajoutidentifiant;
GtkWidget *AZcomboboxajoutmarque;
GtkWidget *AZentryajoutvaleur;
GtkWidget *AZspinbuttonajoutjour;
GtkWidget *AZspinbuttonajoutmois;
GtkWidget *AZspinbuttonajoutannee;
GtkWidget *AZcomboboxajouttype;
GtkWidget *sortiea;

AZspinbuttonajoutjour=lookup_widget(button, "AZspinbuttonajoutjour");
AZspinbuttonajoutmois=lookup_widget(button, "AZspinbuttonajoutmois");
AZspinbuttonajoutannee=lookup_widget(button, "AZspinbuttonajoutannee");
AZcomboboxajouttype=lookup_widget(button, "AZcomboboxajouttype");
AZentryajoutidentifiant=lookup_widget(button,"AZentryajoutidentifiant");
AZcomboboxajoutmarque=lookup_widget(button,"AZcomboboxajoutmarque");
AZentryajoutvaleur=lookup_widget(button,"AZentryajoutvaleur");
sortiea=lookup_widget(button, "AZlabelajoutreus");

strcpy(c.identifiant,gtk_entry_get_text(GTK_ENTRY(AZentryajoutidentifiant)));
strcpy(c.valeur,gtk_entry_get_text(GTK_ENTRY(AZentryajoutvaleur)));
c.date.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(AZspinbuttonajoutjour));
c.date.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(AZspinbuttonajoutmois));
c.date.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(AZspinbuttonajoutannee));

strcpy(Type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(AZcomboboxajouttype)));
strcpy(Marque,gtk_combo_box_get_active_text(GTK_COMBO_BOX(AZcomboboxajoutmarque)));
strcpy(c.type,Type);
strcpy(c.marque,Marque);
AZajout(c);
gtk_label_set_text(GTK_LABEL(sortiea),"Ajout effectué avec succès!");
}


void
on_AZbuttonmodifier_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
CAPTEURS c;char Type[30];char Marque[30];
GtkWidget *AZcomboboxmodiftype;
GtkWidget *AZentrymodifidentifiant;
GtkWidget *AZcomboboxmodifmarque;
GtkWidget *AZspinbuttonmodifjour;
GtkWidget *AZspinbuttonmodifmois;
GtkWidget *AZspinbuttonmodifannee;
GtkWidget *AZentrymodifvaleur;
GtkWidget *sortiem;    
	
AZspinbuttonmodifjour=lookup_widget(button, "AZspinbuttonmodifjour");
AZspinbuttonmodifmois=lookup_widget(button, "AZspinbuttonmodifmois");
AZspinbuttonmodifannee=lookup_widget(button, "AZspinbuttonmodifannee");
AZcomboboxmodiftype=lookup_widget(button, "AZcomboboxmodiftype");
AZentrymodifidentifiant=lookup_widget(button,"AZentrymodifidentifiant");
AZcomboboxmodifmarque=lookup_widget(button,"AZcomboboxmodifmarque");
AZentrymodifvaleur=lookup_widget(button,"AZentrymodifvaleur");
sortiem=lookup_widget(button, "AZlabelmodifreus");

strcpy(c.identifiant,gtk_entry_get_text(GTK_ENTRY(AZentrymodifidentifiant)));
strcpy(c.valeur,gtk_entry_get_text(GTK_ENTRY(AZentrymodifvaleur)));
c.date.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(AZspinbuttonmodifjour));
c.date.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(AZspinbuttonmodifmois));
c.date.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(AZspinbuttonmodifannee));
strcpy(Type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(AZcomboboxmodiftype)));
strcpy(Marque,gtk_combo_box_get_active_text(GTK_COMBO_BOX(AZcomboboxmodifmarque)));
strcpy(c.type,Type);
strcpy(c.marque,Marque);

AZmodification(id,c);
gtk_label_set_text(GTK_LABEL(sortiem),"Modification effectuée avec succès!");
}

void
on_AZbuttonaffichboard_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{
int t,h,m;
char chh[30],cht[30],chm[30],chnm[30];
CAPTEURS c;
GtkWidget *labelt;
GtkWidget *labelh;
GtkWidget *labelm;
GtkWidget *stattreeview;

t=nombret(c);
h=nombreh(c);
m=Mrq_Deff(c);

labelt=lookup_widget(button,"labelt");
labelh=lookup_widget(button,"labelh");
labelm=lookup_widget(button,"labelm");

strcpy(chm,"marque");

sprintf(cht,"%d",t);
sprintf(chh,"%d",h);
sprintf(chnm,"%d",m);
strcat(chm,chnm);

gtk_label_set_text(labelt,cht);
gtk_label_set_text(labelh,chh);
gtk_label_set_text(labelm,chm);

stattreeview=lookup_widget(windowcapteur,"stattreeview");
affichagestat(stattreeview);
}
//-----------------------------------------------LOGIN---------------------------------------------------------------
void
on_buttonretourlogin_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
windowinscription= lookup_widget(button,"windowinscription");
          gtk_widget_destroy(windowinscription);
          windowlogin = create_windowlogin();
          gtk_widget_show(windowlogin);
}


void
on_buttoninscription_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
insc i;
int n=0 ; 
GtkWidget *entryn;
GtkWidget *entryp;
GtkWidget *entryun;
GtkWidget *entrypass , *entryrole ,*err;

entryn=lookup_widget(button,"entryn");
entryp=lookup_widget(button,"entryp");
entryun=lookup_widget(button,"entryun");
entrypass=lookup_widget(button,"entrypass");
entryrole=lookup_widget(button,"entryrole");
err=lookup_widget(button,"deja");

strcpy(i.nom,gtk_entry_get_text(GTK_ENTRY(entryn)));
strcpy(i.prenom,gtk_entry_get_text(GTK_ENTRY(entryp)));
strcpy(i.uname,gtk_entry_get_text(GTK_ENTRY(entryun)));
strcpy(i.password,gtk_entry_get_text(GTK_ENTRY(entrypass)));
strcpy(i.role,gtk_entry_get_text(GTK_ENTRY(entryrole)));

n=verifl(i); 
if (n!=0) {gtk_label_set_text(GTK_LABEL(err)," Déjà Utilisé ! ");}
else {
inscription(i);
gtk_label_set_text(GTK_LABEL(err)," Inscription reussite ! ");
}
}


void
on_buttongoinscription_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{
  windowlogin = lookup_widget(button,"windowlogin");
          gtk_widget_destroy(windowlogin);
          windowinscription = create_windowinscription();
          gtk_widget_show(windowinscription);
}


void
on_buttonlogin_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
auth a;
insc i;
GtkWidget *entryaun ,*err;
GtkWidget *entryapass;
entryaun=lookup_widget(button,"entryaun");
entryapass=lookup_widget(button,"entryapass");
strcpy(a.auname,gtk_entry_get_text(GTK_ENTRY(entryaun)));
strcpy(a.apass,gtk_entry_get_text(GTK_ENTRY(entryapass)));
strcpy(in,i.role);

v=veriflogin(a);
switch(v)
{
case 0 : err=lookup_widget(button,"existepas");
gtk_label_set_text(GTK_LABEL(err)," Ce compte n'esiste pas ! ");break; 

case 1 :  windowlogin = lookup_widget(button,"windowlogin");
          gtk_widget_destroy(windowlogin);
          windowouvrier = create_windowouvrier();
          gtk_widget_show(windowouvrier);break;
       
case 2 :  windowlogin = lookup_widget(button,"windowlogin");
          gtk_widget_destroy(windowlogin);
          windowplantation = create_windowplantation();
          gtk_widget_show(windowplantation);break;


case 3 : windowlogin = lookup_widget(button,"windowlogin");
          gtk_widget_destroy(windowlogin);
          windowtroupeau = create_windowtroupeau();
          gtk_widget_show(windowtroupeau);break;



case 4 :  windowlogin = lookup_widget(button,"windowlogin");
          gtk_widget_destroy(windowlogin);
          windowcapteur = create_windowcapteur();
          gtk_widget_show(windowcapteur);break;


case 5 :  windowlogin = lookup_widget(button,"windowlogin");
          gtk_widget_destroy(windowlogin);
          windowequipement = create_windowequipement();
          gtk_widget_show(windowequipement);break;



case 6 :  windowlogin = lookup_widget(button,"windowlogin");
          gtk_widget_destroy(windowlogin);
          windowclient = create_windowclient();
          gtk_widget_show(windowclient);break;

case 7 :  windowlogin = lookup_widget(button,"windowlogin");
          gtk_widget_destroy(windowlogin);
          windowadmin = create_windowadmin();
          gtk_widget_show(windowadmin);break;

default: err=lookup_widget(button,"existepas");
gtk_label_set_text(GTK_LABEL(err)," ERREUR ! ");break; 

}
}

//---------------------------------------------RETOUR------------------------------------------------
void
on_buttono_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{auth a;

v=veriflogin(a);
windowouvrier = lookup_widget(button,"windowouvrier");
 
 
          if (v==7){gtk_widget_destroy(windowouvrier);
		    windowadmin = create_windowadmin();
                    gtk_widget_show(windowadmin);}
	else        {gtk_widget_destroy(windowouvrier);
          windowlogin = create_windowlogin();
          gtk_widget_show(windowlogin);}
}

//-----------------------------------------ADMIN------------------------------------------------
void
on_buttongologin_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
          windowinscription = lookup_widget(button,"windowinscription");
          gtk_widget_destroy(windowinscription);
          windowlogin = create_windowlogin();
          gtk_widget_show(windowlogin);
}


void
on_buttongop_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
	  windowadmin = lookup_widget(button,"windowadmin");
          gtk_widget_destroy(windowadmin);
          windowplantation = create_windowplantation();
          gtk_widget_show(windowplantation);
}


void
on_buttongoo_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
 	  windowadmin = lookup_widget(button,"windowadmin");
          gtk_widget_destroy(windowadmin);
          windowouvrier = create_windowouvrier();
          gtk_widget_show(windowouvrier);
}


void
on_buttongocp_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
	  windowadmin = lookup_widget(button,"windowadmin");
          gtk_widget_destroy(windowadmin);
          windowcapteur = create_windowcapteur();
          gtk_widget_show(windowcapteur);
}


void
on_buttongoe_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
          windowadmin = lookup_widget(button,"windowadmin");
          gtk_widget_destroy(windowadmin);
          windowequipement = create_windowequipement();
          gtk_widget_show(windowequipement);
}


void
on_buttongot_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
          windowadmin = lookup_widget(button,"windowadmin");
          gtk_widget_destroy(windowadmin);
          windowtroupeau = create_windowtroupeau();
          gtk_widget_show(windowtroupeau);
}


void
on_buttongoauth_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
          windowadmin = lookup_widget(button,"windowadmin");
          gtk_widget_destroy(windowadmin);
          windowlogin = create_windowlogin();
          gtk_widget_show(windowlogin);
}


void
on_buttongocl_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
          windowadmin = lookup_widget(button,"windowadmin");
          gtk_widget_destroy(windowadmin);
          windowclient = create_windowclient();
          gtk_widget_show(windowclient);
}


void
on_buttongoauthentification_clicked    (GtkButton       *button,
                                        gpointer         user_data)
{
          windowacceuil = lookup_widget(button,"windowacceuil");
          gtk_widget_destroy(windowacceuil);
          windowlogin = create_windowlogin();
          gtk_widget_show(windowlogin);
}

