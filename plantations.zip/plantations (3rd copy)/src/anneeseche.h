#include <gtk/gtk.h>
typedef struct
{
int jour;
int mois;
int annee;
}Datee;


typedef struct
{
char type[30];
char identifiant[30];
char nombre[30];
char recolte[30];
Datee date;
}PLANTE;
void anneeseche(GtkWidget* AStreeview);
