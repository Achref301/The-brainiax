#include <gtk/gtk.h>
typedef struct
{
int jour;
int mois;
int annee;
}Datee;


typedef struct
{
char type[30];
char identifiant[30];
int nombre;
int recolte;
Datee date;
}PLANTE;

void ajout(PLANTE p);
void recherche(GtkWidget* AStreeview);
void suppression(char id[30], PLANTE p);
void affichage(GtkWidget* AStreeview);
void modification(char id[30], PLANTE p);
int verif(char x[]);
int verifid(char id[30]);

