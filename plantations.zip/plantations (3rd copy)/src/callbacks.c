#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif



#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include"plante.h"

char id[30],idrech[30];
GtkWidget *windowplantation;
void
on_ASbuttonmenuprincipal_clicked       (GtkButton       *button,
                                        gpointer         user_data)
{
//pas encore
}


void
on_AStreeview_row_activated            (GtkTreeView     *AStreeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
	gchar* identifiant;
	GtkTreeModel *Model = gtk_tree_view_get_model(AStreeview);

		if (gtk_tree_model_get_iter(Model, &iter, path)){
				gtk_tree_model_get(GTK_LIST_STORE(Model),&iter,1,&identifiant, -1);
				strcpy(id,identifiant);}
}


void
on_ASbuttonrechercher_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{

PLANTE p;
GtkWidget *windowplantation;
GtkWidget *ASentryid;
GtkWidget *AStreeview;
GtkWidget *alert2;
FILE*f;
FILE*f2;
alert2=lookup_widget(button, "ASlabelalertrech");
windowplantation=lookup_widget(button,"windowplantation");
ASentryid=lookup_widget(button,"ASentryid");
strcpy(idrech,gtk_entry_get_text(GTK_ENTRY(ASentryid)));
if (verif(idrech)==0){gtk_label_set_text(GTK_LABEL(alert2),"Champs obligatoire!");}
else if (verif(idrech)==1){
f=fopen("plantations.bin","rb");

 if(f!=NULL)
 {
  while(fread(&p,sizeof(PLANTE),1,f))
     {
       f2=fopen("recherche.bin","ab+");
       if  (f2!=NULL)
   {  
     
     if ((strcmp(p.identifiant,idrech)==0))
     { 
     fwrite(&p,sizeof(PLANTE),1,f2);
     }
   
     AStreeview=lookup_widget(windowplantation,"AStreeview");
     recherche(AStreeview);
    
        fclose(f2);
    }

 }
 fclose(f);
}
remove("recherche.bin");}

}


void
on_ASbuttonactualiser_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *AStreeview;
windowplantation=lookup_widget(button,"windowplantation");
AStreeview=lookup_widget(windowplantation,"AStreeview");
affichage(AStreeview);
}


void
on_ASbuttonsupprimer_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
PLANTE p;
	    GtkWidget *AStreeview;
	    windowplantation=lookup_widget(button,"windowplantation");
	    AStreeview=lookup_widget(windowplantation,"AStreeview");
	    suppression(id,p);
            affichage(AStreeview);
          
}


void
on_ASbuttonmodifier_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
		GtkWidget *ASentrymodifid;
		ASentrymodifid=lookup_widget(button,"ASentrymodifid");
                gtk_notebook_next_page(GTK_NOTEBOOK(lookup_widget(windowplantation,"ASnotebook")));
                gtk_notebook_next_page(GTK_NOTEBOOK(lookup_widget(windowplantation,"ASnotebook")));	
		gtk_entry_set_text(GTK_ENTRY(ASentrymodifid),id);	
}



void
on_ASbuttonajouter_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
char Type[30];char x[30];
PLANTE p;
GtkWidget *ASentryajoutid;
GtkWidget *ASspinbuttonajoutnbr;
GtkWidget *ASspinbuttonajoutrecolte;
GtkWidget *ASspinbuttonajoutjour;
GtkWidget *ASspinbuttonajoutmois;
GtkWidget *ASspinbuttonajoutannee;
GtkWidget *AScomboboxajouttype;
GtkWidget *sortiea;
GtkWidget *alert1;


ASspinbuttonajoutjour=lookup_widget(button, "ASspinbuttonajoutjour");
ASspinbuttonajoutmois=lookup_widget(button, "ASspinbuttonajoutmois");
ASspinbuttonajoutannee=lookup_widget(button, "ASspinbuttonajoutannee");
AScomboboxajouttype=lookup_widget(button, "AScomboboxajouttype");
ASentryajoutid=lookup_widget(button,"ASentryajoutid");
ASspinbuttonajoutnbr=lookup_widget(button, "ASspinbuttonajoutnbr");
ASspinbuttonajoutrecolte=lookup_widget(button, "ASspinbuttonajoutrecolte");
sortiea=lookup_widget(button, "ASlabelmsgsucc");
alert1=lookup_widget(button, "ASlabelajoutalertid");

strcpy(x,gtk_entry_get_text(GTK_ENTRY(ASentryajoutid)));
if (verif(x)==0){gtk_label_set_text(GTK_LABEL(alert1),"Champs obligatoire!");}
else if (verif(x)==1){
	if(verifid(x)==0){gtk_label_set_text(GTK_LABEL(alert1),"ID existe déjà");}

	else if(verifid(x)==1){
strcpy(p.identifiant,gtk_entry_get_text(GTK_ENTRY(ASentryajoutid)));
p.nombre=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(ASspinbuttonajoutnbr));
p.recolte=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(ASspinbuttonajoutrecolte));
p.date.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(ASspinbuttonajoutjour));
p.date.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(ASspinbuttonajoutmois));
p.date.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(ASspinbuttonajoutannee));

strcpy(Type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(AScomboboxajouttype)));
strcpy(p.type,Type);
ajout(p);
gtk_label_set_text(GTK_LABEL(sortiea),"Ajout effectué avec succès!");}
}}


void
on_ASbuttonconfirmermodif_clicked      (GtkButton       *button,
                                        gpointer         user_data)
{
PLANTE p;char Type[30];
GtkWidget *AScomboboxmodiftype;
GtkWidget *ASentrymodifid;
GtkWidget *ASspinbuttonmodifnbr;
GtkWidget *ASspinbuttonmodifjour;
GtkWidget *ASspinbuttonmodifmois;
GtkWidget *ASspinbuttonmodifannee;
GtkWidget *ASspinbuttonmodifrecolte;
GtkWidget *sortiem;    
	
ASspinbuttonmodifjour=lookup_widget(button, "ASspinbuttonmodifjour");
ASspinbuttonmodifmois=lookup_widget(button, "ASspinbuttonmodifmois");
ASspinbuttonmodifannee=lookup_widget(button, "ASspinbuttonmodifannee");
AScomboboxmodiftype=lookup_widget(button, "AScomboboxmodiftype");
ASentrymodifid=lookup_widget(button,"ASentrymodifid");
ASspinbuttonmodifnbr=lookup_widget(button, "ASspinbuttonmodifnbr");
ASspinbuttonmodifrecolte=lookup_widget(button, "ASspinbuttonmodifrecolte");
sortiem=lookup_widget(button, "ASlabelmodifreus");




strcpy(p.identifiant,gtk_entry_get_text(GTK_ENTRY(ASentrymodifid)));
p.nombre=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(ASspinbuttonmodifnbr));
p.recolte=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(ASspinbuttonmodifrecolte));
p.date.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(ASspinbuttonmodifjour));
p.date.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(ASspinbuttonmodifmois));
p.date.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(ASspinbuttonmodifannee));
strcpy(Type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(AScomboboxmodiftype)));
strcpy(p.type,Type);
modification(id,p);
gtk_label_set_text(GTK_LABEL(sortiem),"Modification effectuée avec succès!");
}


void
on_ASbuttongoajout_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
gtk_notebook_next_page(GTK_NOTEBOOK(lookup_widget(windowplantation,"ASnotebook")));
}

