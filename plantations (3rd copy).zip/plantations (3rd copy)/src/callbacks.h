#include <gtk/gtk.h>


void
on_ASbuttonmenuprincipal_clicked       (GtkButton       *button,
                                        gpointer         user_data);

void
on_AStreeview_row_activated            (GtkTreeView     *AStreeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_ASbuttonrechercher_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_ASbuttonactualiser_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_ASbuttonsupprimer_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_ASbuttonmodifier_clicked            (GtkButton       *button,
                                        gpointer         user_data);


void
on_ASbuttonajouter_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_ASbuttonconfirmermodif_clicked      (GtkButton       *button,
                                        gpointer         user_data);

void
on_ASbuttongoajout_clicked             (GtkButton       *button,
                                        gpointer         user_data);
